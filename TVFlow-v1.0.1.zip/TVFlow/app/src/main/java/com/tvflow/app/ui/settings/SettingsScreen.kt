package com.tvflow.app.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.tvflow.app.domain.LiveCategory
import com.tvflow.app.domain.LiveChannel
import com.tvflow.app.domain.ServerProfile

@Composable
fun SettingsScreen(
    onAddProfile: () -> Unit,
    onBack: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()
    var pin by remember { mutableStateOf("") }

    Row(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(28.dp),
        horizontalArrangement = Arrangement.spacedBy(22.dp)
    ) {
        LazyColumn(
            Modifier.width(420.dp).fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text("Réglages TVFlow", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Button(onClick = onBack) { Text("← Retour") }
            }

            item {
                SectionTitle("Serveurs Xtream")
                state.profiles.forEach { profile ->
                    ProfileRow(
                        profile = profile,
                        active = profile.id == state.activeProfileId,
                        onActivate = { viewModel.switchProfile(profile.id) },
                        onDelete = { if (state.profiles.size > 1) viewModel.deleteProfile(profile.id) }
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onAddProfile) { Text("+ Ajouter") }
                    Button(onClick = viewModel::refresh, enabled = !state.busy) { Text("Actualiser") }
                }
            }

            item {
                SectionTitle("Lecteur")
                ChoiceRow("Buffer", listOf("FAST", "BALANCED", "SAFE"), state.player.bufferPreset, viewModel::setBuffer)
                ChoiceRow("Image", listOf("FIT", "FILL", "ZOOM"), state.player.videoScale, viewModel::setScale)
                ChoiceRow("Accent", listOf("BLUE", "TEAL", "PURPLE", "AMBER"), state.player.accent, viewModel::setAccent)
                ToggleRow("Sous-titres par défaut", state.player.subtitlesEnabled) { viewModel.setSubtitles(it) }
            }

            item {
                SectionTitle("Contrôle parental")
                Text(if (state.pinConfigured) "PIN configuré" else "Aucun PIN configuré")
                OutlinedTextField(
                    value = pin,
                    onValueChange = { if (it.length <= 8 && it.all(Char::isDigit)) pin = it },
                    label = { Text("PIN 4 à 8 chiffres") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { viewModel.setPin(pin); pin = "" }, enabled = pin.length >= 4) { Text("Enregistrer") }
                    if (state.pinConfigured) Button(onClick = viewModel::clearPin) { Text("Supprimer") }
                }
            }

            state.message?.let { message -> item { Text(message, color = MaterialTheme.colorScheme.primary) } }
        }

        Column(Modifier.weight(1f).fillMaxHeight()) {
            SectionTitle("Organisation des chaînes")
            Text("Masquer, verrouiller et réordonner les catégories. Sélectionne une catégorie pour gérer ses chaînes.")
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                LazyColumn(Modifier.width(360.dp).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    items(state.categories, key = { it.id }) { category ->
                        CategoryManageRow(
                            category = category,
                            selected = state.selectedCategoryId == category.id,
                            onSelect = { viewModel.selectCategory(category.id) },
                            onHide = { viewModel.toggleCategoryHidden(category) },
                            onLock = { viewModel.toggleCategoryLocked(category) },
                            onUp = { viewModel.moveCategory(category, -1) },
                            onDown = { viewModel.moveCategory(category, +1) }
                        )
                    }
                }
                LazyColumn(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    items(state.channels, key = { it.streamId }) { channel ->
                        ChannelManageRow(
                            channel = channel,
                            onHide = { viewModel.toggleChannelHidden(channel) },
                            onUp = { viewModel.moveChannel(channel, -1) },
                            onDown = { viewModel.moveChannel(channel, +1) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 6.dp))
}

@Composable
private fun ProfileRow(profile: ServerProfile, active: Boolean, onActivate: () -> Unit, onDelete: () -> Unit) {
    FocusRow(onClick = onActivate, selected = active) {
        Column(Modifier.weight(1f)) {
            Text((if (active) "● " else "○ ") + profile.name, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal)
            Text(profile.credentials.serverUrl, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text("Suppr.", modifier = Modifier.clickable(onClick = onDelete).padding(8.dp))
    }
}

@Composable
private fun ChoiceRow(label: String, choices: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            choices.forEach { value ->
                Button(onClick = { onSelect(value) }) { Text(if (selected == value) "● $value" else value) }
            }
        }
    }
}

@Composable
private fun ToggleRow(label: String, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Button(onClick = { onChange(!enabled) }) { Text("$label : ${if (enabled) "Oui" else "Non"}") }
}

@Composable
private fun CategoryManageRow(
    category: LiveCategory,
    selected: Boolean,
    onSelect: () -> Unit,
    onHide: () -> Unit,
    onLock: () -> Unit,
    onUp: () -> Unit,
    onDown: () -> Unit
) {
    FocusRow(onClick = onSelect, selected = selected) {
        Text(category.name, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        SmallAction(if (category.isHidden) "Voir" else "Masq.", onHide)
        SmallAction(if (category.isLocked) "🔒" else "🔓", onLock)
        SmallAction("↑", onUp)
        SmallAction("↓", onDown)
    }
}

@Composable
private fun ChannelManageRow(channel: LiveChannel, onHide: () -> Unit, onUp: () -> Unit, onDown: () -> Unit) {
    FocusRow(onClick = {}, selected = false) {
        Text(channel.name, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        SmallAction(if (channel.isHidden) "Voir" else "Masq.", onHide)
        SmallAction("↑", onUp)
        SmallAction("↓", onDown)
    }
}

@Composable
private fun SmallAction(text: String, onClick: () -> Unit) {
    Text(text, modifier = Modifier.clickable(onClick = onClick).padding(horizontal = 7.dp, vertical = 6.dp))
}

@Composable
private fun FocusRow(onClick: () -> Unit, selected: Boolean, content: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    Row(
        Modifier
            .fillMaxWidth()
            .background(
                when {
                    focused -> MaterialTheme.colorScheme.primaryContainer
                    selected -> MaterialTheme.colorScheme.secondaryContainer
                    else -> MaterialTheme.colorScheme.surfaceVariant
                },
                RoundedCornerShape(10.dp)
            )
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .focusable(interactionSource = interaction)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

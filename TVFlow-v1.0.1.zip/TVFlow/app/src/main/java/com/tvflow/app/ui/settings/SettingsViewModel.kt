package com.tvflow.app.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tvflow.app.data.local.PlayerPreferences
import com.tvflow.app.data.local.SettingsStore
import com.tvflow.app.data.repository.XtreamRepository
import com.tvflow.app.domain.LiveCategory
import com.tvflow.app.domain.LiveChannel
import com.tvflow.app.domain.ServerProfile
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    val profiles: List<ServerProfile> = emptyList(),
    val activeProfileId: String? = null,
    val player: PlayerPreferences = PlayerPreferences(),
    val pinConfigured: Boolean = false,
    val categories: List<LiveCategory> = emptyList(),
    val selectedCategoryId: String? = null,
    val channels: List<LiveChannel> = emptyList(),
    val busy: Boolean = false,
    val message: String? = null
)

private data class AccountSettings(
    val profiles: List<ServerProfile>,
    val activeProfileId: String?,
    val player: PlayerPreferences,
    val pinConfigured: Boolean
)

private data class CatalogSettings(
    val categories: List<LiveCategory>,
    val selectedCategoryId: String?,
    val channels: List<LiveChannel>
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val repository: XtreamRepository,
    private val settingsStore: SettingsStore
) : ViewModel() {
    private val selectedCategoryId = MutableStateFlow<String?>(null)
    private val busy = MutableStateFlow(false)
    private val message = MutableStateFlow<String?>(null)

    private val channels = selectedCategoryId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else repository.observeManageChannels(id)
    }

    private val account = combine(
        repository.profiles,
        repository.activeProfileId,
        settingsStore.playerPreferences,
        settingsStore.parentalPinConfigured
    ) { profiles, activeId, player, pinConfigured ->
        AccountSettings(profiles, activeId, player, pinConfigured)
    }

    private val catalog = combine(
        repository.observeManageCategories(),
        selectedCategoryId,
        channels
    ) { categories, selectedId, channelList ->
        CatalogSettings(categories, selectedId, channelList)
    }

    val state: StateFlow<SettingsUiState> = combine(account, catalog, busy, message) { accountState, catalogState, isBusy, info ->
        SettingsUiState(
            profiles = accountState.profiles,
            activeProfileId = accountState.activeProfileId,
            player = accountState.player,
            pinConfigured = accountState.pinConfigured,
            categories = catalogState.categories,
            selectedCategoryId = catalogState.selectedCategoryId,
            channels = catalogState.channels,
            busy = isBusy,
            message = info
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsUiState())

    fun selectCategory(id: String) { selectedCategoryId.value = id }

    fun switchProfile(id: String) = launchBusy("Profil activé") { repository.switchProfile(id); selectedCategoryId.value = null }
    fun deleteProfile(id: String) = launchBusy("Profil supprimé") { repository.deleteProfile(id); selectedCategoryId.value = null }
    fun refresh() = launchBusy("Catalogues actualisés") { repository.refreshCatalog(); repository.refreshMediaCatalog() }

    fun setBuffer(value: String) { viewModelScope.launch { settingsStore.setBufferPreset(value) } }
    fun setScale(value: String) { viewModelScope.launch { settingsStore.setVideoScale(value) } }
    fun setSubtitles(value: Boolean) { viewModelScope.launch { settingsStore.setSubtitlesEnabled(value) } }
    fun setAccent(value: String) { viewModelScope.launch { settingsStore.setAccent(value) } }

    fun setPin(pin: String) = launchBusy("PIN parental enregistré") { settingsStore.setParentalPin(pin) }
    fun clearPin() = launchBusy("PIN parental supprimé") {
        repository.observeManageCategories().first().filter { it.isLocked }.forEach { repository.setCategoryLocked(it.id, false) }
        settingsStore.clearParentalPin()
    }

    fun toggleCategoryHidden(category: LiveCategory) = launchBusy(null) { repository.setCategoryHidden(category.id, !category.isHidden) }
    fun toggleCategoryLocked(category: LiveCategory) {
        if (!category.isLocked && !state.value.pinConfigured) {
            message.value = "Configure d’abord un PIN parental"
            return
        }
        launchBusy(null) { repository.setCategoryLocked(category.id, !category.isLocked) }
    }
    fun moveCategory(category: LiveCategory, delta: Int) = launchBusy(null) { repository.moveCategory(category.id, delta) }
    fun toggleChannelHidden(channel: LiveChannel) = launchBusy(null) { repository.setChannelHidden(channel.streamId, !channel.isHidden) }
    fun moveChannel(channel: LiveChannel, delta: Int) {
        val category = selectedCategoryId.value ?: return
        launchBusy(null) { repository.moveChannel(category, channel.streamId, delta) }
    }

    private fun launchBusy(successMessage: String?, block: suspend () -> Unit) {
        viewModelScope.launch {
            busy.value = true
            val result = runCatching { block() }
            message.value = result.exceptionOrNull()?.message ?: successMessage
            busy.value = false
        }
    }
}

@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.tvflow.app.ui.player

import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil3.compose.AsyncImage
import com.tvflow.app.domain.LiveChannel
import com.tvflow.app.ui.common.PlayerLifecycleEffect
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class SidePanel { NONE, CHANNELS, OPTIONS }
private enum class VideoScale(val label: String, val resizeMode: Int) {
    FIT("Ajuster", AspectRatioFrameLayout.RESIZE_MODE_FIT),
    FILL("Remplir", AspectRatioFrameLayout.RESIZE_MODE_FILL),
    ZOOM("Zoom", AspectRatioFrameLayout.RESIZE_MODE_ZOOM)
}

private data class PlayerTrack(
    val group: Tracks.Group,
    val trackIndex: Int,
    val label: String,
    val type: Int,
    val selected: Boolean
)

@Composable
fun PlayerScreen(viewModel: PlayerViewModel = hiltViewModel()) {
    val context = LocalContext.current
    val state by viewModel.uiState.collectAsState()
    val focusRequester = remember { FocusRequester() }
    var overlayVisible by remember { mutableStateOf(true) }
    var sidePanel by remember { mutableStateOf(SidePanel.NONE) }
    var overlayEpoch by remember { mutableStateOf(0L) }
    var retryEpoch by remember { mutableIntStateOf(0) }
    var videoScale by remember { mutableStateOf(VideoScale.FIT) }
    var audioTracks by remember { mutableStateOf(emptyList<PlayerTrack>()) }
    var subtitleTracks by remember { mutableStateOf(emptyList<PlayerTrack>()) }
    var subtitlesDisabled by remember { mutableStateOf(false) }
    var automaticRetryCount by remember { mutableIntStateOf(0) }

    val player = remember(state.bufferPreset) {
        val (minBuffer, maxBuffer, playBuffer, rebuffer) = when (state.bufferPreset) {
            "SAFE" -> intArrayOf(8_000, 30_000, 2_000, 3_500)
            "BALANCED" -> intArrayOf(5_000, 20_000, 1_200, 2_000)
            else -> intArrayOf(3_000, 12_000, 750, 1_500)
        }
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(minBuffer, maxBuffer, playBuffer, rebuffer)
            .build()
        ExoPlayer.Builder(context)
            .setLoadControl(loadControl)
            .build()
            .apply { playWhenReady = true }
    }

    LaunchedEffect(state.videoScale) {
        videoScale = VideoScale.entries.firstOrNull { it.name == state.videoScale } ?: VideoScale.FIT
    }

    LaunchedEffect(state.subtitlesEnabled, player) {
        subtitlesDisabled = !state.subtitlesEnabled
        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !state.subtitlesEnabled)
            .build()
    }

    PlayerLifecycleEffect(player)

    fun refreshTracks() {
        val groups = player.currentTracks.groups
        fun mapType(type: Int): List<PlayerTrack> = groups
            .filter { it.type == type }
            .flatMap { group ->
                (0 until group.length).mapNotNull { index ->
                    if (!group.isTrackSupported(index)) return@mapNotNull null
                    val format = group.getTrackFormat(index)
                    val language = format.language?.uppercase(Locale.getDefault())
                    val base = format.label?.takeIf { it.isNotBlank() }
                        ?: language
                        ?: when (type) {
                            C.TRACK_TYPE_AUDIO -> "Audio ${index + 1}"
                            else -> "Sous-titre ${index + 1}"
                        }
                    PlayerTrack(group, index, base, type, group.isTrackSelected(index))
                }
            }
        audioTracks = mapType(C.TRACK_TYPE_AUDIO)
        subtitleTracks = mapType(C.TRACK_TYPE_TEXT)
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                viewModel.reportPlayerError(error.errorCodeName)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    viewModel.reportPlayerError(null)
                    refreshTracks()
                }
            }

            override fun onTracksChanged(tracks: Tracks) {
                refreshTracks()
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    LaunchedEffect(state.streamUrl) { automaticRetryCount = 0 }

    LaunchedEffect(state.playerError) {
        if (state.playerError != null && automaticRetryCount < 2) {
            automaticRetryCount++
            delay(automaticRetryCount * 1_500L)
            retryEpoch++
        }
    }

    LaunchedEffect(state.streamUrl, retryEpoch, player) {
        state.streamUrl?.let { url ->
            player.stop()
            player.clearMediaItems()
            player.setMediaItem(MediaItem.fromUri(url))
            player.prepare()
            player.playWhenReady = true
            overlayVisible = true
            sidePanel = SidePanel.NONE
            overlayEpoch = System.currentTimeMillis()
        }
    }

    LaunchedEffect(overlayEpoch, sidePanel) {
        if (overlayEpoch == 0L || sidePanel != SidePanel.NONE) return@LaunchedEffect
        delay(4_500)
        overlayVisible = false
    }

    LaunchedEffect(Unit) { focusRequester.requestFocus() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .focusRequester(focusRequester)
            .focusable()
            .onPreviewKeyEvent { event ->
                val native = event.nativeKeyEvent
                if (native.action != KeyEvent.ACTION_DOWN) return@onPreviewKeyEvent false
                val isLongPress = native.repeatCount > 0
                when (native.keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                        if (sidePanel == SidePanel.NONE) viewModel.previousChannel() else return@onPreviewKeyEvent false
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_MEDIA_NEXT -> {
                        if (sidePanel == SidePanel.NONE) viewModel.nextChannel() else return@onPreviewKeyEvent false
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_MENU -> {
                        sidePanel = if (sidePanel == SidePanel.CHANNELS) SidePanel.NONE else SidePanel.CHANNELS
                        overlayVisible = true
                        overlayEpoch = System.currentTimeMillis()
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        sidePanel = if (sidePanel == SidePanel.OPTIONS) SidePanel.NONE else SidePanel.OPTIONS
                        overlayVisible = true
                        overlayEpoch = System.currentTimeMillis()
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                        if (isLongPress) {
                            sidePanel = SidePanel.OPTIONS
                            overlayVisible = true
                        } else if (sidePanel == SidePanel.NONE) {
                            overlayVisible = !overlayVisible
                        } else {
                            return@onPreviewKeyEvent false
                        }
                        overlayEpoch = if (overlayVisible) System.currentTimeMillis() else 0L
                        true
                    }
                    KeyEvent.KEYCODE_INFO -> {
                        overlayVisible = !overlayVisible
                        overlayEpoch = if (overlayVisible) System.currentTimeMillis() else 0L
                        true
                    }
                    KeyEvent.KEYCODE_F, KeyEvent.KEYCODE_MEDIA_RECORD -> {
                        viewModel.toggleFavorite()
                        overlayVisible = true
                        overlayEpoch = System.currentTimeMillis()
                        true
                    }
                    KeyEvent.KEYCODE_0 -> {
                        viewModel.returnToPreviousChannel()
                        true
                    }
                    KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                        if (player.isPlaying) player.pause() else player.play()
                        true
                    }
                    KeyEvent.KEYCODE_BACK -> {
                        if (sidePanel != SidePanel.NONE) {
                            sidePanel = SidePanel.NONE
                            true
                        } else false
                    }
                    else -> false
                }
            }
    ) {
        AndroidView(
            factory = {
                PlayerView(it).apply {
                    this.player = player
                    useController = false
                    keepScreenOn = true
                    resizeMode = videoScale.resizeMode
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { it.resizeMode = videoScale.resizeMode },
            modifier = Modifier.fillMaxSize()
        )

        AnimatedVisibility(
            visible = sidePanel == SidePanel.CHANNELS,
            modifier = Modifier.align(Alignment.CenterStart)
        ) {
            MiniGuide(
                channels = state.channels,
                selectedStreamId = state.channel?.streamId,
                onSelect = {
                    viewModel.selectChannel(it)
                    sidePanel = SidePanel.NONE
                }
            )
        }

        AnimatedVisibility(
            visible = sidePanel == SidePanel.OPTIONS,
            modifier = Modifier.align(Alignment.CenterEnd)
        ) {
            PlayerOptionsPanel(
                scale = videoScale,
                audioTracks = audioTracks,
                subtitleTracks = subtitleTracks,
                subtitlesDisabled = subtitlesDisabled,
                hasPreviousChannel = state.previousStreamId != null,
                onScaleChange = {
                    videoScale = it
                    viewModel.saveVideoScale(it.name)
                },
                onAudioTrack = { track -> selectTrack(player, track) },
                onSubtitleTrack = { track ->
                    subtitlesDisabled = false
                    viewModel.saveSubtitlesEnabled(true)
                    player.trackSelectionParameters = player.trackSelectionParameters
                        .buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                        .setOverrideForType(TrackSelectionOverride(track.group.mediaTrackGroup, track.trackIndex))
                        .build()
                },
                onDisableSubtitles = {
                    subtitlesDisabled = true
                    viewModel.saveSubtitlesEnabled(false)
                    player.trackSelectionParameters = player.trackSelectionParameters
                        .buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                        .build()
                },
                onFavorite = viewModel::toggleFavorite,
                onPreviousChannel = {
                    viewModel.returnToPreviousChannel()
                    sidePanel = SidePanel.NONE
                }
            )
        }

        AnimatedVisibility(
            visible = overlayVisible,
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            PlayerOverlay(
                state = state,
                onRetry = { retryEpoch++ }
            )
        }
    }
}

private fun selectTrack(player: ExoPlayer, track: PlayerTrack) {
    player.trackSelectionParameters = player.trackSelectionParameters
        .buildUpon()
        .setOverrideForType(TrackSelectionOverride(track.group.mediaTrackGroup, track.trackIndex))
        .build()
}

@Composable
private fun MiniGuide(
    channels: List<LiveChannel>,
    selectedStreamId: Int?,
    onSelect: (Int) -> Unit
) {
    val selectedIndex = channels.indexOfFirst { it.streamId == selectedStreamId }.coerceAtLeast(0)
    val from = (selectedIndex - 5).coerceAtLeast(0)
    val to = (selectedIndex + 7).coerceAtMost(channels.size)
    val visibleChannels = channels.subList(from, to)

    Column(
        modifier = Modifier
            .width(390.dp)
            .fillMaxHeight()
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.96f))
            .padding(18.dp)
    ) {
        Text("Chaînes", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(visibleChannels, key = { it.streamId }) { channel ->
                FocusActionRow(
                    selected = channel.streamId == selectedStreamId,
                    onClick = { onSelect(channel.streamId) }
                ) {
                    AsyncImage(model = channel.logoUrl, contentDescription = null, modifier = Modifier.width(46.dp))
                    Spacer(Modifier.width(12.dp))
                    Text(channel.name, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun PlayerOptionsPanel(
    scale: VideoScale,
    audioTracks: List<PlayerTrack>,
    subtitleTracks: List<PlayerTrack>,
    subtitlesDisabled: Boolean,
    hasPreviousChannel: Boolean,
    onScaleChange: (VideoScale) -> Unit,
    onAudioTrack: (PlayerTrack) -> Unit,
    onSubtitleTrack: (PlayerTrack) -> Unit,
    onDisableSubtitles: () -> Unit,
    onFavorite: () -> Unit,
    onPreviousChannel: () -> Unit
) {
    Column(
        modifier = Modifier
            .width(430.dp)
            .fillMaxHeight()
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.97f))
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Réglages lecteur", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))

        Text("Image", style = MaterialTheme.typography.titleMedium)
        VideoScale.entries.forEach { item ->
            FocusActionRow(selected = item == scale, onClick = { onScaleChange(item) }) {
                Text(if (item == scale) "● ${item.label}" else "○ ${item.label}")
            }
        }

        if (audioTracks.isNotEmpty()) {
            Text("Audio", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 6.dp))
            audioTracks.take(6).forEach { track ->
                FocusActionRow(selected = track.selected, onClick = { onAudioTrack(track) }) {
                    Text(if (track.selected) "● ${track.label}" else "○ ${track.label}")
                }
            }
        }

        Text("Sous-titres", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 6.dp))
        FocusActionRow(selected = subtitlesDisabled, onClick = onDisableSubtitles) {
            Text(if (subtitlesDisabled) "● Désactivés" else "○ Désactivés")
        }
        subtitleTracks.take(5).forEach { track ->
            FocusActionRow(selected = !subtitlesDisabled && track.selected, onClick = { onSubtitleTrack(track) }) {
                Text(if (!subtitlesDisabled && track.selected) "● ${track.label}" else "○ ${track.label}")
            }
        }

        Text("Actions", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 6.dp))
        FocusActionRow(onClick = onFavorite) { Text("★ Ajouter / retirer des favoris") }
        if (hasPreviousChannel) {
            FocusActionRow(onClick = onPreviousChannel) { Text("↶ Revenir à la chaîne précédente") }
        }
    }
}

@Composable
private fun FocusActionRow(
    selected: Boolean = false,
    onClick: () -> Unit,
    content: @Composable RowScope.() -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                when {
                    focused -> MaterialTheme.colorScheme.primaryContainer
                    selected -> MaterialTheme.colorScheme.secondaryContainer
                    else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
                },
                RoundedCornerShape(10.dp)
            )
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .focusable(interactionSource = interaction)
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

@Composable
private fun PlayerOverlay(state: PlayerUiState, onRetry: () -> Unit) {
    val current = state.nowProgram
    val nowSeconds = System.currentTimeMillis() / 1000L
    val progress = if (current != null && current.stopTimestamp > current.startTimestamp) {
        ((nowSeconds - current.startTimestamp).toFloat() / (current.stopTimestamp - current.startTimestamp).toFloat())
            .coerceIn(0f, 1f)
    } else 0f

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
            )
            .padding(horizontal = 32.dp, vertical = 18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = if (state.channelIndex >= 0) "${state.channelIndex + 1}" else "–",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.width(54.dp)
            )
            AsyncImage(model = state.channel?.logoUrl, contentDescription = null, modifier = Modifier.width(72.dp))
            Spacer(Modifier.width(20.dp))
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(state.channel?.name ?: "Chargement…", style = MaterialTheme.typography.headlineSmall)
                if (current != null) {
                    Text(
                        "${formatTime(current.startTimestamp)} - ${formatTime(current.stopTimestamp)}  ${current.title}",
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                } else {
                    Text(if (state.epgLoading) "Chargement du programme…" else "Programme indisponible")
                }
                state.nextProgram?.let {
                    Text(
                        "Ensuite ${formatTime(it.startTimestamp)}  ${it.title}",
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                state.playerError?.let { error ->
                    Text(
                        "Flux indisponible ($error) • Réessayer",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.clickable(onClick = onRetry)
                    )
                }
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(if (state.channel?.isFavorite == true) "★ Favori" else "☆ Favori")
                Text(if (state.channelCount > 0) "${state.channelIndex + 1}/${state.channelCount}" else "")
                Text("↑↓ Zapper   ← Chaînes   → Réglages", style = MaterialTheme.typography.bodySmall)
                Text("0 Chaîne précédente   OK Infos", style = MaterialTheme.typography.bodySmall)
            }
        }
        if (current != null) {
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
        }
    }
}

private fun formatTime(timestampSeconds: Long): String =
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(timestampSeconds * 1000L))

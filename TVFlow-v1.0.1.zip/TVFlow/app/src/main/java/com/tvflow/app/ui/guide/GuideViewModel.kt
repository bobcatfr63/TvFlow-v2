package com.tvflow.app.ui.guide

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tvflow.app.data.repository.XtreamRepository
import com.tvflow.app.data.local.SettingsStore
import com.tvflow.app.domain.EpgProgram
import com.tvflow.app.domain.LiveCategory
import com.tvflow.app.domain.LiveChannel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar
import javax.inject.Inject

private const val WINDOW_SECONDS = 2 * 60 * 60L
private const val STEP_SECONDS = 30 * 60L
const val GUIDE_ALL = "__all__"
const val GUIDE_FAVORITES = "__favorites__"

data class GuideUiState(
    val categories: List<LiveCategory> = emptyList(),
    val selectedCategoryId: String? = null,
    val channels: List<LiveChannel> = emptyList(),
    val selectedChannel: LiveChannel? = null,
    val previewChannel: LiveChannel? = null,
    val previewStreamUrl: String? = null,
    val selectedProgram: EpgProgram? = null,
    val programs: List<EpgProgram> = emptyList(),
    val timelinePrograms: Map<Int, List<EpgProgram>> = emptyMap(),
    val windowStart: Long = currentHalfHour(),
    val windowEnd: Long = currentHalfHour() + WINDOW_SECONDS,
    val loading: Boolean = false,
    val pinRequiredCategory: LiveCategory? = null,
    val pinError: String? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class GuideViewModel @Inject constructor(
    private val repository: XtreamRepository,
    private val settingsStore: SettingsStore
) : ViewModel() {
    private val selectedCategoryId = MutableStateFlow<String?>(null)
    private val selectedStreamId = MutableStateFlow<Int?>(null)
    private val previewStreamId = MutableStateFlow<Int?>(null)
    private val selectedProgramStart = MutableStateFlow<Long?>(null)
    private val loading = MutableStateFlow(false)
    private val windowStart = MutableStateFlow(currentHalfHour())
    private val pinRequiredCategory = MutableStateFlow<LiveCategory?>(null)
    private val pinError = MutableStateFlow<String?>(null)

    private val categories = repository.observeCategories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val channels = selectedCategoryId.flatMapLatest { id ->
        when (id) {
            null -> flowOf(emptyList())
            GUIDE_ALL -> repository.observeAllChannels()
            GUIDE_FAVORITES -> repository.observeFavorites()
            else -> repository.observeChannels(id)
        }
    }


    private val previewChannel = previewStreamId.flatMapLatest { id ->
        if (id == null) flowOf(null) else repository.observeChannel(id)
    }

    private val selectedPrograms = selectedStreamId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else repository.observeEpg(id)
    }

    private val timelinePrograms = channels.flatMapLatest { list ->
        val ids = list.take(24).map { it.streamId }
        if (ids.isEmpty()) flowOf(emptyList()) else repository.observeEpgForStreams(ids)
    }

    private val core = combine(
        categories,
        selectedCategoryId,
        channels,
        selectedStreamId,
        selectedPrograms
    ) { cats, catId, channelList, streamId, epg ->
        GuideUiState(
            categories = cats,
            selectedCategoryId = catId,
            channels = channelList,
            selectedChannel = channelList.firstOrNull { it.streamId == streamId },
            programs = epg
        )
    }

    private val content = combine(core, timelinePrograms, windowStart, selectedProgramStart) { base, timeline, start, selectedStart ->
        val grouped = timeline.groupBy { it.streamId }
        val channel = base.selectedChannel
        val channelPrograms = channel?.let { grouped[it.streamId].orEmpty() }.orEmpty()
        val now = System.currentTimeMillis() / 1000L
        val selected = channelPrograms.firstOrNull { it.startTimestamp == selectedStart }
            ?: channelPrograms.firstOrNull { it.isLiveAt(now) }
            ?: channelPrograms.firstOrNull { it.stopTimestamp > now }
            ?: channelPrograms.firstOrNull()

        base.copy(
            selectedProgram = selected,
            timelinePrograms = grouped,
            windowStart = start,
            windowEnd = start + WINDOW_SECONDS
        )
    }

    private val contentWithPreview = combine(
        content,
        previewChannel,
        repository.savedCredentials
    ) { value, preview, credentials ->
        value.copy(
            previewChannel = preview,
            previewStreamUrl = if (credentials != null && preview != null) {
                repository.streamUrl(credentials, preview)
            } else null
        )
    }

    val state: StateFlow<GuideUiState> = combine(contentWithPreview, loading, pinRequiredCategory, pinError) { value, busy, locked, error ->
        value.copy(loading = busy, pinRequiredCategory = locked, pinError = error)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), GuideUiState())

    init {
        viewModelScope.launch {
            categories.collect { cats ->
                if (selectedCategoryId.value == null && cats.isNotEmpty()) selectCategory(GUIDE_ALL)
            }
        }
        viewModelScope.launch {
            repository.activeProfileId.drop(1).collect {
                selectedCategoryId.value = null
                selectedStreamId.value = null
                selectedProgramStart.value = null
                previewStreamId.value = null
                pinRequiredCategory.value = null
                pinError.value = null
                selectCategory(GUIDE_ALL)
            }
        }
    }

    fun selectCategory(id: String) {
        if (selectedCategoryId.value == id) return
        val category = categories.value.firstOrNull { it.id == id }
        if (category?.isLocked == true) {
            pinRequiredCategory.value = category
            pinError.value = null
            return
        }
        applyCategory(id)
    }

    fun confirmParentalPin(pin: String) {
        val category = pinRequiredCategory.value ?: return
        viewModelScope.launch {
            if (settingsStore.verifyParentalPin(pin)) {
                pinRequiredCategory.value = null
                pinError.value = null
                applyCategory(category.id)
            } else pinError.value = "PIN incorrect"
        }
    }

    fun dismissParentalPin() { pinRequiredCategory.value = null; pinError.value = null }

    private fun applyCategory(id: String) {
        selectedCategoryId.value = id
        selectedStreamId.value = null
        selectedProgramStart.value = null
        viewModelScope.launch {
            val list = channels.first { it.isNotEmpty() || selectedCategoryId.value != id }
            if (selectedCategoryId.value == id && list.isNotEmpty()) {
                selectChannel(list.first().streamId)
                if (previewStreamId.value == null) previewStreamId.value = list.first().streamId
                prefetch(list)
            }
        }
    }

    fun selectChannel(streamId: Int) {
        if (selectedStreamId.value != streamId) selectedProgramStart.value = null
        selectedStreamId.value = streamId
        viewModelScope.launch { runCatching { repository.refreshEpg(streamId, 16) } }
    }

    fun selectProgram(streamId: Int, startTimestamp: Long) {
        selectedStreamId.value = streamId
        selectedProgramStart.value = startTimestamp
    }

    fun previewChannel(streamId: Int) {
        if (previewStreamId.value == streamId) return
        previewStreamId.value = streamId
        if (selectedStreamId.value != streamId) selectChannel(streamId)
    }

    fun previousWindow() {
        windowStart.value -= STEP_SECONDS
    }

    fun nextWindow() {
        windowStart.value += STEP_SECONDS
    }

    fun jumpToNow() {
        windowStart.value = currentHalfHour()
    }

    private fun prefetch(list: List<LiveChannel>) {
        viewModelScope.launch {
            loading.value = true
            runCatching {
                repository.prefetchEpg(list.take(24).map { it.streamId }, limit = 16, parallelism = 3)
            }
            loading.value = false
        }
    }
}

private fun currentHalfHour(): Long {
    val calendar = Calendar.getInstance().apply {
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
        set(Calendar.MINUTE, if (get(Calendar.MINUTE) < 30) 0 else 30)
    }
    return calendar.timeInMillis / 1000L
}

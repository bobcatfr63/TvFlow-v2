package com.tvflow.app.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.security.MessageDigest
import javax.inject.Inject
import javax.inject.Singleton

private val Context.playerSettingsDataStore by preferencesDataStore(name = "tvflow_player_settings")

data class PlayerPreferences(
    val bufferPreset: String = "FAST",
    val videoScale: String = "FIT",
    val subtitlesEnabled: Boolean = true,
    val accent: String = "BLUE"
)

@Singleton
class SettingsStore @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val buffer = stringPreferencesKey("buffer_preset")
        val scale = stringPreferencesKey("video_scale")
        val subtitles = booleanPreferencesKey("subtitles_enabled")
        val accent = stringPreferencesKey("accent")
        val pinHash = stringPreferencesKey("parental_pin_hash")
    }

    val playerPreferences: Flow<PlayerPreferences> = context.playerSettingsDataStore.data.map { prefs ->
        PlayerPreferences(
            bufferPreset = prefs[Keys.buffer] ?: "FAST",
            videoScale = prefs[Keys.scale] ?: "FIT",
            subtitlesEnabled = prefs[Keys.subtitles] ?: true,
            accent = prefs[Keys.accent] ?: "BLUE"
        )
    }

    val parentalPinConfigured: Flow<Boolean> = context.playerSettingsDataStore.data.map { !it[Keys.pinHash].isNullOrBlank() }

    suspend fun setBufferPreset(value: String) = context.playerSettingsDataStore.edit { it[Keys.buffer] = value }
    suspend fun setVideoScale(value: String) = context.playerSettingsDataStore.edit { it[Keys.scale] = value }
    suspend fun setSubtitlesEnabled(value: Boolean) = context.playerSettingsDataStore.edit { it[Keys.subtitles] = value }
    suspend fun setAccent(value: String) = context.playerSettingsDataStore.edit { it[Keys.accent] = value }

    suspend fun setParentalPin(pin: String) {
        require(pin.length in 4..8 && pin.all(Char::isDigit)) { "Le PIN doit contenir 4 à 8 chiffres" }
        context.playerSettingsDataStore.edit { it[Keys.pinHash] = hash(pin) }
    }

    suspend fun clearParentalPin() = context.playerSettingsDataStore.edit { it.remove(Keys.pinHash) }

    suspend fun verifyParentalPin(pin: String): Boolean =
        context.playerSettingsDataStore.data.map { prefs -> prefs[Keys.pinHash] == hash(pin) }.first()

    private fun hash(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray())
        .joinToString("") { "%02x".format(it) }

}

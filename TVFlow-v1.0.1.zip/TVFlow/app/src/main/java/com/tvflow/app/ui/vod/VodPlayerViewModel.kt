package com.tvflow.app.ui.vod

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tvflow.app.data.repository.XtreamRepository
import com.tvflow.app.domain.Episode
import com.tvflow.app.domain.VodItem
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class VodPlayerUiState(
    val streamUrl: String? = null,
    val mediaKey: String = "",
    val resumePositionMs: Long = 0L,
    val title: String = "",
    val imageUrl: String? = null,
    val error: String? = null
)

@HiltViewModel
class VodPlayerViewModel @Inject constructor(
    private val repository: XtreamRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {
    private val kind: String = savedStateHandle["kind"] ?: "vod"
    private val mediaId: String = checkNotNull(savedStateHandle["mediaId"])
    private val title: String = savedStateHandle["title"] ?: "Lecture"
    private val ext: String? = savedStateHandle.get<String>("ext")?.takeUnless { it == "_" }

    private val _state = MutableStateFlow(VodPlayerUiState(title = title))
    val state: StateFlow<VodPlayerUiState> = _state.asStateFlow()

    init { prepare() }

    fun saveProgress(positionMs: Long, durationMs: Long) {
        val current = _state.value
        val key = current.mediaKey.takeIf { it.isNotBlank() } ?: return
        viewModelScope.launch {
            repository.savePlaybackPosition(
                mediaKey = key,
                positionMs = positionMs,
                durationMs = durationMs,
                title = current.title,
                imageUrl = current.imageUrl,
                kind = kind,
                mediaId = mediaId,
                containerExtension = ext
            )
        }
    }

    private fun prepare() {
        viewModelScope.launch {
            runCatching {
                val key: String
                val url: String
                if (kind == "episode") {
                    val episode = Episode(mediaId, 0, 0, title, ext, null, null)
                    key = "episode:$mediaId"
                    url = repository.episodeUrl(episode)
                } else {
                    val id = mediaId.toInt()
                    val item = VodItem(id, title, "", null, null, null, ext)
                    key = "vod:$id"
                    url = repository.vodUrl(item)
                }
                val resume = repository.playbackPosition(key)?.positionMs ?: 0L
                Triple(key, url, resume)
            }.onSuccess { (key, url, resume) ->
                _state.value = VodPlayerUiState(streamUrl = url, mediaKey = key, resumePositionMs = resume, title = title)
            }.onFailure { error ->
                _state.value = VodPlayerUiState(title = title, error = error.message ?: "Lecture impossible")
            }
        }
    }
}

package com.tvflow.app.ui.library

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil3.compose.AsyncImage
import com.tvflow.app.domain.MediaType
import com.tvflow.app.domain.SeriesItem
import com.tvflow.app.domain.VodItem

@Composable
fun MediaLibraryScreen(
    onVodSelected: (VodItem) -> Unit,
    onSeriesSelected: (SeriesItem) -> Unit,
    viewModel: MediaLibraryViewModel = hiltViewModel()
) {
    val categories by viewModel.categories.collectAsState()
    val selectedId by viewModel.selectedCategoryId.collectAsState()
    val vod by viewModel.vod.collectAsState()
    val series by viewModel.series.collectAsState()

    LaunchedEffect(Unit) {
        if (categories.isEmpty()) viewModel.refresh()
    }
    LaunchedEffect(categories, selectedId) {
        if (selectedId == null && categories.isNotEmpty()) viewModel.selectCategory(categories.first().id)
    }

    Column(Modifier.fillMaxSize().padding(top = 24.dp)) {
        Text(
            if (viewModel.type == MediaType.VOD) "Films" else "Séries",
            style = MaterialTheme.typography.headlineLarge,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp)
        )
        Row(Modifier.fillMaxSize()) {
            LazyColumn(
                modifier = Modifier.width(280.dp).fillMaxHeight().padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories, key = { it.id }) { category ->
                    Card(onClick = { viewModel.selectCategory(category.id) }, modifier = Modifier.fillMaxWidth()) {
                        Text(category.name, modifier = Modifier.padding(14.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }

            LazyRow(
                modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (viewModel.type == MediaType.VOD) {
                    items(vod, key = { it.streamId }) { item -> MediaPoster(item.name, item.posterUrl, item.rating) { onVodSelected(item) } }
                } else {
                    items(series, key = { it.seriesId }) { item -> MediaPoster(item.name, item.coverUrl, item.rating) { onSeriesSelected(item) } }
                }
            }
        }
    }
}

@Composable
private fun MediaPoster(name: String, image: String?, rating: String?, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.width(190.dp)) {
        Column {
            AsyncImage(
                model = image,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().width(190.dp)
            )
            Text(name, modifier = Modifier.padding(10.dp), maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (!rating.isNullOrBlank()) Text("★ $rating", modifier = Modifier.padding(start = 10.dp, bottom = 10.dp), style = MaterialTheme.typography.bodySmall)
        }
    }
}

package com.tvflow.app.ui.series

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.tvflow.app.domain.Episode

@Composable
fun SeriesDetailsScreen(
    seriesName: String,
    onPlayEpisode: (Episode) -> Unit,
    viewModel: SeriesDetailsViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()
    val seasons = state.episodes.map { it.season }.distinct()
    val episodes = state.episodes.filter { state.selectedSeason == null || it.season == state.selectedSeason }

    Column(Modifier.fillMaxSize().padding(32.dp)) {
        Text(seriesName, style = MaterialTheme.typography.headlineLarge)
        if (state.loading) {
            CircularProgressIndicator(modifier = Modifier.align(Alignment.CenterHorizontally).padding(32.dp))
            return@Column
        }
        state.error?.let {
            Text(it, color = MaterialTheme.colorScheme.error)
            Button(onClick = viewModel::retry, modifier = Modifier.padding(top = 12.dp)) { Text("Réessayer") }
            return@Column
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(vertical = 18.dp)) {
            items(seasons) { season ->
                Button(onClick = { viewModel.selectSeason(season) }) { Text("Saison $season") }
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(episodes, key = { it.id }) { episode ->
                Card(onClick = { onPlayEpisode(episode) }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("S${episode.season} • E${episode.episodeNumber}  ${episode.title}", style = MaterialTheme.typography.titleMedium)
                            episode.plot?.takeIf { it.isNotBlank() }?.let { Text(it, maxLines = 2, style = MaterialTheme.typography.bodySmall) }
                        }
                        Text("▶")
                    }
                }
            }
        }
    }
}

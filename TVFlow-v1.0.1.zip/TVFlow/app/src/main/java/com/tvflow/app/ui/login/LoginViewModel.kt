package com.tvflow.app.ui.login

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tvflow.app.data.repository.XtreamRepository
import com.tvflow.app.domain.XtreamCredentials
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class LoginUiState(
    val profileName: String = "",
    val server: String = "",
    val username: String = "",
    val password: String = "",
    val loading: Boolean = false,
    val success: Boolean = false,
    val error: String? = null
)

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val repository: XtreamRepository
) : ViewModel() {
    private val _state = MutableStateFlow(LoginUiState())
    val state: StateFlow<LoginUiState> = _state.asStateFlow()

    fun setProfileName(value: String) { _state.value = _state.value.copy(profileName = value, error = null) }
    fun setServer(value: String) { _state.value = _state.value.copy(server = value, error = null) }
    fun setUsername(value: String) { _state.value = _state.value.copy(username = value, error = null) }
    fun setPassword(value: String) { _state.value = _state.value.copy(password = value, error = null) }

    fun login() {
        val current = _state.value
        if (current.server.isBlank() || current.username.isBlank() || current.password.isBlank()) {
            _state.value = current.copy(error = "Serveur, utilisateur et mot de passe sont obligatoires")
            return
        }
        viewModelScope.launch {
            _state.value = current.copy(loading = true, error = null)
            runCatching {
                repository.login(
                    XtreamCredentials(current.server, current.username, current.password),
                    current.profileName.takeIf { it.isNotBlank() }
                )
            }.onSuccess {
                _state.value = _state.value.copy(loading = false, success = true)
            }.onFailure { e ->
                _state.value = _state.value.copy(loading = false, error = e.message ?: "Connexion impossible")
            }
        }
    }
}

package com.tvflow.app.ui.library

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tvflow.app.data.repository.XtreamRepository
import com.tvflow.app.domain.MediaCategory
import com.tvflow.app.domain.MediaType
import com.tvflow.app.domain.SeriesItem
import com.tvflow.app.domain.VodItem
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class MediaLibraryViewModel @Inject constructor(
    private val repository: XtreamRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {
    val type: MediaType = runCatching { MediaType.valueOf(savedStateHandle.get<String>("type") ?: MediaType.VOD.name) }
        .getOrDefault(MediaType.VOD)

    val categories: StateFlow<List<MediaCategory>> = repository.observeMediaCategories(type)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val selectedCategory = MutableStateFlow<String?>(null)
    val selectedCategoryId: StateFlow<String?> = selectedCategory

    val vod: StateFlow<List<VodItem>> = selectedCategory.flatMapLatest { id ->
        if (type == MediaType.VOD && id != null) repository.observeVod(id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val series: StateFlow<List<SeriesItem>> = selectedCategory.flatMapLatest { id ->
        if (type == MediaType.SERIES && id != null) repository.observeSeries(id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun selectCategory(id: String) { selectedCategory.value = id }

    fun refresh() {
        viewModelScope.launch { runCatching { repository.refreshMediaCatalog() } }
    }
}

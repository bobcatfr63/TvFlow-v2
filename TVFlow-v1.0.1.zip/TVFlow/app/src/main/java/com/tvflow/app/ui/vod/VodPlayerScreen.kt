package com.tvflow.app.ui.vod

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.tvflow.app.ui.common.PlayerLifecycleEffect
import kotlinx.coroutines.delay

@Composable
fun VodPlayerScreen(viewModel: VodPlayerViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current
    val player = remember { ExoPlayer.Builder(context).build() }

    PlayerLifecycleEffect(player)

    LaunchedEffect(state.streamUrl) {
        val url = state.streamUrl ?: return@LaunchedEffect
        player.setMediaItem(MediaItem.fromUri(url))
        player.prepare()
        if (state.resumePositionMs > 0L) player.seekTo(state.resumePositionMs)
        player.playWhenReady = true
    }


    LaunchedEffect(player, state.mediaKey) {
        if (state.mediaKey.isBlank()) return@LaunchedEffect
        while (true) {
            delay(15_000L)
            viewModel.saveProgress(
                player.currentPosition.coerceAtLeast(0L),
                player.duration.coerceAtLeast(0L)
            )
        }
    }

    DisposableEffect(player) {
        onDispose {
            viewModel.saveProgress(player.currentPosition.coerceAtLeast(0L), player.duration.coerceAtLeast(0L))
            player.release()
        }
    }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        when {
            state.error != null -> Text(state.error ?: "Erreur")
            state.streamUrl == null -> CircularProgressIndicator()
            else -> AndroidView(
                factory = {
                    PlayerView(it).apply {
                        this.player = player
                        useController = true
                        keepScreenOn = true
                        layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

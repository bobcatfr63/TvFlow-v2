package com.tvflow.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun TVFlowTheme(accent: String = "BLUE", content: @Composable () -> Unit) {
    val primary = when (accent) {
        "TEAL" -> Color(0xFF35C7B7)
        "PURPLE" -> Color(0xFFB69CFF)
        "AMBER" -> Color(0xFFFFC857)
        else -> Color(0xFF4BA8FF)
    }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = primary,
            secondary = primary,
            primaryContainer = primary.copy(alpha = 0.28f),
            secondaryContainer = primary.copy(alpha = 0.18f)
        ),
        content = content
    )
}

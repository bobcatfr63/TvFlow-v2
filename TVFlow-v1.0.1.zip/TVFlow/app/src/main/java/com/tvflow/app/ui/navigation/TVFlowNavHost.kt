package com.tvflow.app.ui.navigation

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.tvflow.app.domain.MediaType
import com.tvflow.app.ui.dashboard.DashboardScreen
import com.tvflow.app.ui.home.HomeScreen
import com.tvflow.app.ui.guide.GuideScreen
import com.tvflow.app.ui.library.MediaLibraryScreen
import com.tvflow.app.ui.login.LoginScreen
import com.tvflow.app.ui.player.PlayerScreen
import com.tvflow.app.ui.search.SearchScreen
import com.tvflow.app.ui.settings.SettingsScreen
import com.tvflow.app.ui.series.SeriesDetailsScreen
import com.tvflow.app.ui.startup.StartupScreen
import com.tvflow.app.ui.vod.VodPlayerScreen

@Composable
fun TVFlowNavHost() {
    val navController = rememberNavController()

    fun openLive(streamId: Int, name: String, categoryId: String) {
        navController.navigate("player/$streamId/${Uri.encode(name)}/${Uri.encode(categoryId)}")
    }

    fun openVod(streamId: Int, title: String, extension: String?) {
        navController.navigate("vodPlayer/vod/$streamId/${Uri.encode(title)}/${Uri.encode(extension ?: "_")}")
    }

    NavHost(navController = navController, startDestination = "startup") {
        composable("startup") {
            StartupScreen(
                onLoggedIn = { navController.navigate("dashboard") { popUpTo("startup") { inclusive = true } } },
                onLoggedOut = { navController.navigate("login") { popUpTo("startup") { inclusive = true } } }
            )
        }
        composable("login") {
            LoginScreen(
                onLoggedIn = { navController.navigate("dashboard") { popUpTo("login") { inclusive = true } } }
            )
        }
        composable("dashboard") {
            DashboardScreen(
                onLive = { navController.navigate("home") },
                onGuide = { navController.navigate("guide") },
                onVod = { navController.navigate("library/${MediaType.VOD.name}") },
                onSeries = { navController.navigate("library/${MediaType.SERIES.name}") },
                onSearch = { navController.navigate("search") },
                onSettings = { navController.navigate("settings") },
                onChannel = { channel -> openLive(channel.streamId, channel.name, channel.categoryId) },
                onResume = { item ->
                    navController.navigate(
                        "vodPlayer/${item.kind}/${Uri.encode(item.mediaId)}/${Uri.encode(item.title)}/${Uri.encode(item.containerExtension ?: "_")}"
                    )
                }
            )
        }
        composable("home") {
            HomeScreen(onPlay = { channel -> openLive(channel.streamId, channel.name, channel.categoryId) })
        }
        composable("guide") {
            GuideScreen(
                onPlay = { channel -> openLive(channel.streamId, channel.name, channel.categoryId) },
                onDashboard = { navController.navigate("dashboard") { launchSingleTop = true } },
                onSearch = { navController.navigate("search") { launchSingleTop = true } },
                onVod = { navController.navigate("library/${MediaType.VOD.name}") { launchSingleTop = true } },
                onSeries = { navController.navigate("library/${MediaType.SERIES.name}") { launchSingleTop = true } },
                onSettings = { navController.navigate("settings") { launchSingleTop = true } }
            )
        }
        composable("settings") {
            SettingsScreen(
                onAddProfile = { navController.navigate("addProfile") },
                onBack = { navController.popBackStack() }
            )
        }
        composable("addProfile") {
            LoginScreen(onLoggedIn = { navController.popBackStack() })
        }
        composable(
            route = "library/{type}",
            arguments = listOf(navArgument("type") { type = NavType.StringType })
        ) {
            MediaLibraryScreen(
                onVodSelected = { item -> openVod(item.streamId, item.name, item.containerExtension) },
                onSeriesSelected = { item -> navController.navigate("series/${item.seriesId}/${Uri.encode(item.name)}") }
            )
        }
        composable("search") {
            SearchScreen(
                onLive = { item -> openLive(item.streamId, item.name, item.categoryId) },
                onVod = { item -> openVod(item.streamId, item.name, item.containerExtension) },
                onSeries = { item -> navController.navigate("series/${item.seriesId}/${Uri.encode(item.name)}") }
            )
        }
        composable(
            route = "series/{seriesId}/{name}",
            arguments = listOf(
                navArgument("seriesId") { type = NavType.IntType },
                navArgument("name") { type = NavType.StringType }
            )
        ) { entry ->
            val name = Uri.decode(entry.arguments?.getString("name").orEmpty())
            SeriesDetailsScreen(
                seriesName = name,
                onPlayEpisode = { episode ->
                    navController.navigate(
                        "vodPlayer/episode/${Uri.encode(episode.id)}/${Uri.encode(episode.title)}/${Uri.encode(episode.containerExtension ?: "_")}"
                    )
                }
            )
        }
        composable(
            route = "vodPlayer/{kind}/{mediaId}/{title}/{ext}",
            arguments = listOf(
                navArgument("kind") { type = NavType.StringType },
                navArgument("mediaId") { type = NavType.StringType },
                navArgument("title") { type = NavType.StringType },
                navArgument("ext") { type = NavType.StringType }
            )
        ) {
            VodPlayerScreen()
        }
        composable(
            route = "player/{streamId}/{name}/{categoryId}",
            arguments = listOf(
                navArgument("streamId") { type = NavType.IntType },
                navArgument("name") { type = NavType.StringType },
                navArgument("categoryId") { type = NavType.StringType }
            )
        ) {
            PlayerScreen()
        }
    }
}

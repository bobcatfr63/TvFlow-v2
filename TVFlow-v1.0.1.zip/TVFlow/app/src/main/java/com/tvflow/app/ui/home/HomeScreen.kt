package com.tvflow.app.ui.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil3.compose.AsyncImage
import com.tvflow.app.domain.LiveChannel
import com.tvflow.app.ui.common.ParentalPinDialog

@Composable
fun HomeScreen(
    onPlay: (LiveChannel) -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val categories by viewModel.categories.collectAsState()
    val channels by viewModel.channels.collectAsState()
    val selectedSource by viewModel.selectedSource.collectAsState()
    val pinRequiredCategory by viewModel.pinRequiredCategory.collectAsState()
    val pinError by viewModel.pinError.collectAsState()

    pinRequiredCategory?.let { category ->
        ParentalPinDialog(
            categoryName = category.name,
            error = pinError,
            onConfirm = viewModel::confirmParentalPin,
            onDismiss = viewModel::dismissParentalPin
        )
    }

    LaunchedEffect(categories, selectedSource) {
        if (selectedSource == null && categories.isNotEmpty()) {
            viewModel.selectCategory(categories.first().id)
        }
    }

    Row(modifier = Modifier.fillMaxSize().padding(top = 24.dp)) {
        LazyColumn(
            modifier = Modifier.width(310.dp).fillMaxHeight().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Text("TVFlow", style = MaterialTheme.typography.headlineLarge, modifier = Modifier.padding(12.dp))
            }
            item {
                MenuCard("★ Favoris") { viewModel.selectFavorites() }
            }
            item {
                MenuCard("↻ Récents") { viewModel.selectRecent() }
            }
            items(categories, key = { it.id }) { category ->
                MenuCard(category.name) { viewModel.selectCategory(category.id) }
            }
        }

        Box(modifier = Modifier.fillMaxSize()) {
            if (channels.isEmpty()) {
                val message = when (selectedSource) {
                    ChannelSource.Favorites -> "Aucune chaîne favorite"
                    ChannelSource.Recent -> "Aucune chaîne regardée récemment"
                    null -> "Chargement du catalogue…"
                    is ChannelSource.Category -> "Aucune chaîne dans cette catégorie"
                }
                Text(message, modifier = Modifier.align(Alignment.Center))
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(channels, key = { it.streamId }) { channel ->
                        ChannelRow(
                            channel = channel,
                            onClick = { onPlay(channel) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MenuCard(label: String, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().focusable(),
        colors = CardDefaults.cardColors()
    ) {
        Text(label, modifier = Modifier.padding(16.dp))
    }
}

@Composable
private fun ChannelRow(channel: LiveChannel, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = channel.logoUrl,
                contentDescription = null,
                modifier = Modifier.width(72.dp).padding(end = 12.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(channel.name, style = MaterialTheme.typography.titleMedium)
                if (!channel.epgChannelId.isNullOrBlank()) {
                    Text(channel.epgChannelId, style = MaterialTheme.typography.bodySmall)
                }
            }
            if (channel.isFavorite) {
                Text("★", style = MaterialTheme.typography.titleLarge)
            }
        }
    }
}

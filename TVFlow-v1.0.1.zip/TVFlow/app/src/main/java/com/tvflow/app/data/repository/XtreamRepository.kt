package com.tvflow.app.data.repository

import android.util.Base64
import com.tvflow.app.data.local.CredentialsStore
import com.tvflow.app.data.local.EpgProgramEntity
import com.tvflow.app.data.local.LiveCategoryEntity
import com.tvflow.app.data.local.LiveChannelEntity
import com.tvflow.app.data.local.MediaCategoryEntity
import com.tvflow.app.data.local.PlaybackPositionEntity
import com.tvflow.app.data.local.SeriesItemEntity
import com.tvflow.app.data.local.TVFlowDao
import com.tvflow.app.data.local.VodItemEntity
import com.tvflow.app.data.remote.XtreamApi
import com.tvflow.app.domain.EpgProgram
import com.tvflow.app.domain.Episode
import com.tvflow.app.domain.LiveCategory
import com.tvflow.app.domain.LiveChannel
import com.tvflow.app.domain.MediaCategory
import com.tvflow.app.domain.MediaType
import com.tvflow.app.domain.PlaybackPosition
import com.tvflow.app.domain.SeriesItem
import com.tvflow.app.domain.ServerProfile
import com.tvflow.app.domain.VodItem
import com.tvflow.app.domain.XtreamCredentials
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class XtreamRepository @Inject constructor(
    private val api: XtreamApi,
    private val dao: TVFlowDao,
    private val credentialsStore: CredentialsStore,
    private val okHttpClient: OkHttpClient
) {
    val savedCredentials = credentialsStore.credentials
    val profiles = credentialsStore.profiles
    val activeProfile = credentialsStore.activeProfile
    val activeProfileId = credentialsStore.activeProfileId

    suspend fun login(credentials: XtreamCredentials, displayName: String? = null) {
        val normalized = credentials.copy(serverUrl = normalizeServer(credentials.serverUrl))
        authenticate(normalized)
        credentialsStore.save(normalized, displayName)
        val profileId = currentProfileId()
        refreshCatalog(normalized, profileId)
        runCatching { refreshMediaCatalog(normalized, profileId) }
    }

    suspend fun switchProfile(profileId: String) {
        credentialsStore.switchProfile(profileId)
        refreshCatalog()
        runCatching { refreshMediaCatalog() }
    }

    suspend fun deleteProfile(profileId: String) {
        val wasActive = activeProfileId.first() == profileId
        dao.deleteProfileData(profileId)
        credentialsStore.deleteProfile(profileId)
        if (wasActive && savedCredentials.first() != null) {
            refreshCatalog()
            runCatching { refreshMediaCatalog() }
        }
    }

    suspend fun refreshCatalog() {
        val credentials = savedCredentials.first() ?: error("Aucun serveur IPTV configuré")
        refreshCatalog(credentials, currentProfileId())
    }

    suspend fun refreshMediaCatalog() {
        val credentials = savedCredentials.first() ?: error("Aucun serveur IPTV configuré")
        refreshMediaCatalog(credentials, currentProfileId())
    }

    private suspend fun authenticate(credentials: XtreamCredentials) {
        val response = api.authenticate(playerApi(credentials.serverUrl), credentials.username, credentials.password)
        val authenticated = response.userInfo?.auth == 1 || response.userInfo?.status.equals("Active", true)
        if (!authenticated) error(response.userInfo?.message ?: "Identifiants Xtream refusés")
    }

    private suspend fun refreshCatalog(credentials: XtreamCredentials, profileId: String) {
        val apiUrl = playerApi(credentials.serverUrl)
        val categories = api.getLiveCategories(apiUrl, credentials.username, credentials.password)
        val channels = api.getLiveStreams(apiUrl, credentials.username, credentials.password)
        dao.replaceCatalog(
            profileId = profileId,
            categories = categories.mapIndexed { index, dto ->
                LiveCategoryEntity(profileId, dto.categoryId, dto.categoryName, index)
            },
            channels = channels.map { dto ->
                LiveChannelEntity(
                    profileId = profileId,
                    streamId = dto.streamId,
                    name = dto.name,
                    categoryId = dto.categoryId.orEmpty(),
                    logoUrl = dto.streamIcon?.takeIf { it.isNotBlank() },
                    epgChannelId = dto.epgChannelId?.takeIf { it.isNotBlank() },
                    streamType = dto.streamType ?: "live"
                )
            }
        )
    }

    private suspend fun refreshMediaCatalog(credentials: XtreamCredentials, profileId: String) = coroutineScope {
        val apiUrl = playerApi(credentials.serverUrl)
        val vodCategoriesDeferred = async { api.getVodCategories(apiUrl, credentials.username, credentials.password) }
        val seriesCategoriesDeferred = async { api.getSeriesCategories(apiUrl, credentials.username, credentials.password) }
        val vodDeferred = async { api.getVodStreams(apiUrl, credentials.username, credentials.password) }
        val seriesDeferred = async { api.getSeries(apiUrl, credentials.username, credentials.password) }

        val vodCategories = vodCategoriesDeferred.await()
        val seriesCategories = seriesCategoriesDeferred.await()
        val vod = vodDeferred.await()
        val series = seriesDeferred.await()

        dao.clearMediaCategories(profileId, MediaType.VOD.name)
        dao.clearMediaCategories(profileId, MediaType.SERIES.name)
        dao.clearVod(profileId)
        dao.clearSeries(profileId)
        dao.upsertMediaCategories(vodCategories.mapIndexed { index, dto ->
            MediaCategoryEntity(profileId, dto.categoryId, dto.categoryName, MediaType.VOD.name, index)
        })
        dao.upsertMediaCategories(seriesCategories.mapIndexed { index, dto ->
            MediaCategoryEntity(profileId, dto.categoryId, dto.categoryName, MediaType.SERIES.name, index)
        })
        dao.upsertVod(vod.map { dto ->
            VodItemEntity(profileId, dto.streamId, dto.name, dto.categoryId.orEmpty(), dto.streamIcon?.takeIf { it.isNotBlank() }, dto.rating, dto.added?.toLongOrNull(), dto.containerExtension)
        })
        dao.upsertSeries(series.map { dto ->
            SeriesItemEntity(profileId, dto.seriesId, dto.name, dto.categoryId.orEmpty(), dto.cover?.takeIf { it.isNotBlank() }, dto.rating, dto.plot)
        })
    }

    fun observeEpg(streamId: Int): Flow<List<EpgProgram>> = activeProfileId.flatMapLatest { profileId ->
        if (profileId == null) flowOf(emptyList()) else dao.observeEpg(profileId, streamId)
    }.map { list -> list.map { EpgProgram(it.streamId, it.startTimestamp, it.stopTimestamp, it.title, it.description, it.hasArchive) } }

    fun observeEpgForStreams(streamIds: List<Int>): Flow<List<EpgProgram>> = activeProfileId.flatMapLatest { profileId ->
        if (profileId == null || streamIds.isEmpty()) flowOf(emptyList()) else dao.observeEpgForStreams(profileId, streamIds)
    }.map { list -> list.map { EpgProgram(it.streamId, it.startTimestamp, it.stopTimestamp, it.title, it.description, it.hasArchive) } }

    suspend fun refreshEpg(streamId: Int, limit: Int = 8) {
        val credentials = savedCredentials.first() ?: return
        val profileId = currentProfileId()
        val response = api.getShortEpg(playerApi(credentials.serverUrl), credentials.username, credentials.password, streamId = streamId, limit = limit)
        val items = response.listings.mapNotNull { dto ->
            val start = dto.startTimestamp?.toLongOrNull() ?: return@mapNotNull null
            val stop = dto.stopTimestamp?.toLongOrNull() ?: return@mapNotNull null
            EpgProgramEntity(profileId, streamId, start, stop, decodeEpgText(dto.title).ifBlank { "Programme sans titre" }, decodeEpgText(dto.description).takeIf { it.isNotBlank() }, dto.hasArchive == 1)
        }
        dao.clearEpg(profileId, streamId)
        if (items.isNotEmpty()) dao.upsertEpg(items)
        dao.deleteExpiredEpg(profileId, System.currentTimeMillis() / 1000L - 86_400L)
    }

    fun observeCategories(): Flow<List<LiveCategory>> = activeProfileId.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.observeCategories(id) }
        .map { list -> list.map { LiveCategory(it.id, it.name, it.sortOrder, it.isHidden, it.isLocked) } }

    fun observeManageCategories(): Flow<List<LiveCategory>> = activeProfileId.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.observeManageCategories(id) }
        .map { list -> list.map { LiveCategory(it.id, it.name, it.sortOrder, it.isHidden, it.isLocked) } }

    fun observeChannels(categoryId: String): Flow<List<LiveChannel>> = activeProfileId.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.observeChannels(id, categoryId) }.map(::mapChannels)
    fun observeManageChannels(categoryId: String): Flow<List<LiveChannel>> = activeProfileId.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.observeManageChannels(id, categoryId) }.map(::mapChannels)
    fun observeAllChannels(): Flow<List<LiveChannel>> = activeProfileId.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.observeAllChannels(id) }.map(::mapChannels)
    fun observeChannel(streamId: Int): Flow<LiveChannel?> = activeProfileId.flatMapLatest { id -> if (id == null) flowOf(null) else dao.observeChannel(id, streamId) }.map { it?.toDomain() }
    fun observeFavorites(): Flow<List<LiveChannel>> = activeProfileId.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.observeFavorites(id) }.map(::mapChannels)
    fun observeRecentChannels(limit: Int = 20): Flow<List<LiveChannel>> = activeProfileId.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.observeRecentChannels(id, limit) }.map(::mapChannels)
    fun searchLive(query: String): Flow<List<LiveChannel>> = activeProfileId.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.searchLive(id, query) }.map(::mapChannels)

    fun observeMediaCategories(type: MediaType): Flow<List<MediaCategory>> = activeProfileId.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.observeMediaCategories(id, type.name) }.map { list ->
        list.map { MediaCategory(it.id, it.name, MediaType.valueOf(it.type), it.sortOrder) }
    }
    fun observeVod(categoryId: String): Flow<List<VodItem>> = activeProfileId.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.observeVod(id, categoryId) }.map { list -> list.map { it.toDomain() } }
    fun observeSeries(categoryId: String): Flow<List<SeriesItem>> = activeProfileId.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.observeSeries(id, categoryId) }.map { list -> list.map { it.toDomain() } }
    fun searchVod(query: String): Flow<List<VodItem>> = activeProfileId.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.searchVod(id, query) }.map { list -> list.map { it.toDomain() } }
    fun searchSeries(query: String): Flow<List<SeriesItem>> = activeProfileId.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.searchSeries(id, query) }.map { list -> list.map { it.toDomain() } }

    suspend fun getSeriesEpisodes(seriesId: Int): List<Episode> {
        val credentials = savedCredentials.first() ?: return emptyList()
        val response = api.getSeriesInfo(playerApi(credentials.serverUrl), credentials.username, credentials.password, seriesId = seriesId)
        return response.episodes.entries.sortedBy { it.key.toIntOrNull() ?: Int.MAX_VALUE }.flatMap { (seasonKey, episodes) ->
            val season = seasonKey.toIntOrNull() ?: 0
            episodes.mapIndexed { index, dto ->
                Episode(dto.id, season, dto.episodeNumber ?: index + 1, dto.title?.ifBlank { null } ?: "Épisode ${dto.episodeNumber ?: index + 1}", dto.containerExtension, dto.info?.movieImage, dto.info?.plot)
            }
        }
    }

    suspend fun toggleFavorite(streamId: Int) = dao.toggleFavorite(currentProfileId(), streamId)
    suspend fun markWatched(streamId: Int) = dao.markWatched(currentProfileId(), streamId, System.currentTimeMillis())
    suspend fun setChannelHidden(streamId: Int, hidden: Boolean) = dao.setChannelHidden(currentProfileId(), streamId, hidden)
    suspend fun setCategoryHidden(categoryId: String, hidden: Boolean) = dao.setCategoryHidden(currentProfileId(), categoryId, hidden)
    suspend fun setCategoryLocked(categoryId: String, locked: Boolean) = dao.setCategoryLocked(currentProfileId(), categoryId, locked)

    suspend fun moveCategory(categoryId: String, delta: Int) {
        val profileId = currentProfileId()
        val list = dao.observeManageCategories(profileId).first()
        val index = list.indexOfFirst { it.id == categoryId }
        if (index < 0) return
        val target = (index + delta).coerceIn(0, list.lastIndex)
        if (target == index) return
        val reordered = list.toMutableList().apply { add(target, removeAt(index)) }
        reordered.forEachIndexed { order, category -> dao.setCategoryOrder(profileId, category.id, order) }
    }

    suspend fun moveChannel(categoryId: String, streamId: Int, delta: Int) {
        val profileId = currentProfileId()
        val list = dao.observeManageChannels(profileId, categoryId).first()
        val index = list.indexOfFirst { it.streamId == streamId }
        if (index < 0) return
        val target = (index + delta).coerceIn(0, list.lastIndex)
        if (target == index) return
        val reordered = list.toMutableList().apply { add(target, removeAt(index)) }
        reordered.forEachIndexed { order, channel -> dao.setChannelOrder(profileId, channel.streamId, order) }
    }

    fun streamUrl(credentials: XtreamCredentials, channel: LiveChannel): String = "${normalizeServer(credentials.serverUrl)}/live/${credentials.username}/${credentials.password}/${channel.streamId}.ts"

    suspend fun vodUrl(item: VodItem): String {
        val credentials = savedCredentials.first() ?: error("Aucun serveur IPTV configuré")
        val ext = item.containerExtension?.ifBlank { null } ?: "mp4"
        return "${normalizeServer(credentials.serverUrl)}/movie/${credentials.username}/${credentials.password}/${item.streamId}.$ext"
    }

    suspend fun episodeUrl(episode: Episode): String {
        val credentials = savedCredentials.first() ?: error("Aucun serveur IPTV configuré")
        val ext = episode.containerExtension?.ifBlank { null } ?: "mp4"
        return "${normalizeServer(credentials.serverUrl)}/series/${credentials.username}/${credentials.password}/${episode.id}.$ext"
    }

    suspend fun savePlaybackPosition(mediaKey: String, positionMs: Long, durationMs: Long, title: String, imageUrl: String?, kind: String, mediaId: String, containerExtension: String?) {
        val profileId = currentProfileId()
        if (positionMs < 5_000L || durationMs <= 0L) return
        if (durationMs - positionMs < 30_000L || positionMs >= durationMs * 0.95) dao.clearPlaybackPosition(profileId, mediaKey)
        else dao.savePlaybackPosition(PlaybackPositionEntity(profileId, mediaKey, positionMs, durationMs, System.currentTimeMillis(), title, imageUrl, kind, mediaId, containerExtension))
    }

    suspend fun playbackPosition(mediaKey: String): PlaybackPosition? = dao.getPlaybackPosition(currentProfileId(), mediaKey)?.toDomain()
    fun observeContinueWatching(limit: Int = 20): Flow<List<PlaybackPosition>> = activeProfileId.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.observePlaybackPositions(id, limit) }.map { list -> list.map { it.toDomain() } }

    suspend fun prefetchEpg(streamIds: List<Int>, limit: Int = 8, parallelism: Int = 4) = coroutineScope {
        val semaphore = Semaphore(parallelism.coerceAtLeast(1))
        streamIds.distinct().take(24).map { streamId -> async { semaphore.withPermit { runCatching { refreshEpg(streamId, limit) } } } }.forEach { it.await() }
    }

    suspend fun warmLiveStreams(channels: List<LiveChannel>) {
        val credentials = savedCredentials.first() ?: return
        val warmClient = okHttpClient.newBuilder().connectTimeout(900, TimeUnit.MILLISECONDS).readTimeout(900, TimeUnit.MILLISECONDS).callTimeout(1_200, TimeUnit.MILLISECONDS).build()
        withContext(Dispatchers.IO) {
            channels.distinctBy { it.streamId }.take(2).forEach { channel ->
                val request = Request.Builder().url(streamUrl(credentials, channel)).header("Range", "bytes=0-16383").build()
                runCatching { warmClient.newCall(request).execute().use { response -> if (response.isSuccessful) response.body?.byteStream()?.read(ByteArray(16 * 1024)) } }
            }
        }
    }

    suspend fun logout() { credentialsStore.clear() }

    private suspend fun currentProfileId(): String = activeProfileId.first() ?: error("Aucun profil IPTV actif")
    private fun mapChannels(list: List<LiveChannelEntity>) = list.map { it.toDomain() }
    private fun LiveChannelEntity.toDomain() = LiveChannel(streamId, name, categoryId, logoUrl, epgChannelId, streamType, isFavorite, lastWatchedAt, isHidden, customOrder)
    private fun VodItemEntity.toDomain() = VodItem(streamId, name, categoryId, posterUrl, rating, added, containerExtension)
    private fun SeriesItemEntity.toDomain() = SeriesItem(seriesId, name, categoryId, coverUrl, rating, plot)
    private fun PlaybackPositionEntity.toDomain() = PlaybackPosition(mediaKey, positionMs, durationMs, updatedAt, title, imageUrl, kind, mediaId, containerExtension)

    private fun decodeEpgText(value: String?): String {
        if (value.isNullOrBlank()) return ""
        return runCatching {
            val decoded = Base64.decode(value, Base64.DEFAULT)
            val text = decoded.toString(Charsets.UTF_8)
            if (text.isNotBlank() && text.all { !it.isISOControl() || it == '\n' || it == '\t' }) text else value
        }.getOrDefault(value)
    }

    private fun playerApi(server: String): String = "${normalizeServer(server)}/player_api.php"
    private fun normalizeServer(raw: String): String {
        var value = raw.trim().trimEnd('/')
        if (!value.startsWith("http://") && !value.startsWith("https://")) value = "http://$value"
        return value
    }
}

package com.tvflow.app.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tvflow.app.data.repository.XtreamRepository
import com.tvflow.app.domain.LiveChannel
import com.tvflow.app.domain.PlaybackPosition
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

data class DashboardUiState(
    val serverName: String? = null,
    val continueWatching: List<PlaybackPosition> = emptyList(),
    val favorites: List<LiveChannel> = emptyList(),
    val recentChannels: List<LiveChannel> = emptyList()
)

@HiltViewModel
class DashboardViewModel @Inject constructor(
    repository: XtreamRepository
) : ViewModel() {
    val state: StateFlow<DashboardUiState> = combine(
        repository.observeContinueWatching(12),
        repository.observeFavorites(),
        repository.observeRecentChannels(12),
        repository.activeProfile
    ) { watching, favorites, recents, profile ->
        DashboardUiState(
            serverName = profile?.name,
            continueWatching = watching,
            favorites = favorites.take(12),
            recentChannels = recents.take(12)
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        DashboardUiState()
    )
}

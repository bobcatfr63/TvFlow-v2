package com.tvflow.app.ui.dashboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.tvflow.app.domain.LiveChannel
import com.tvflow.app.domain.PlaybackPosition

@Composable
fun DashboardScreen(
    onLive: () -> Unit,
    onGuide: () -> Unit,
    onVod: () -> Unit,
    onSeries: () -> Unit,
    onSearch: () -> Unit,
    onSettings: () -> Unit,
    onResume: (PlaybackPosition) -> Unit,
    onChannel: (LiveChannel) -> Unit,
    viewModel: DashboardViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 48.dp, vertical = 30.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item {
            Text("TVFlow", style = MaterialTheme.typography.displayMedium)
            Text(
                state.serverName?.let { "Serveur actif : $it" } ?: "Rapide. Simple. Pensé pour la télé.",
                style = MaterialTheme.typography.titleMedium
            )
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(onClick = onLive) { Text("Direct") }
                Button(onClick = onGuide) { Text("Guide TV") }
                Button(onClick = onVod) { Text("Films") }
                Button(onClick = onSeries) { Text("Séries") }
                Button(onClick = onSearch) { Text("Recherche") }
                Button(onClick = onSettings) { Text("Réglages") }
            }
        }

        if (state.recentChannels.isNotEmpty()) {
            item { ChannelRail("Chaînes récentes", state.recentChannels, onChannel) }
        }
        if (state.favorites.isNotEmpty()) {
            item { ChannelRail("Favoris", state.favorites, onChannel) }
        }
        if (state.continueWatching.isNotEmpty()) {
            item { ContinueRail(state.continueWatching, onResume) }
        }
    }
}

@Composable
private fun ChannelRail(title: String, channels: List<LiveChannel>, onChannel: (LiveChannel) -> Unit) {
    Column {
        Text(title, style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(10.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(channels, key = { it.streamId }) { channel ->
                Button(onClick = { onChannel(channel) }, modifier = Modifier.width(220.dp)) {
                    Text(channel.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun ContinueRail(items: List<PlaybackPosition>, onResume: (PlaybackPosition) -> Unit) {
    Column {
        Text("Continuer à regarder", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(10.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(items, key = { it.mediaKey }) { item ->
                Button(onClick = { onResume(item) }, modifier = Modifier.width(250.dp)) {
                    Column(Modifier.fillMaxWidth()) {
                        Text(item.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(progress = { item.progress }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(4.dp))
                        Text("${(item.progress * 100).toInt()} %", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

package com.tvflow.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface TVFlowDao {
    @Query("SELECT * FROM live_categories WHERE profileId = :profileId AND isHidden = 0 ORDER BY CASE WHEN customOrder IS NULL THEN 1 ELSE 0 END, customOrder, sortOrder, name")
    fun observeCategories(profileId: String): Flow<List<LiveCategoryEntity>>

    @Query("SELECT * FROM live_categories WHERE profileId = :profileId ORDER BY CASE WHEN customOrder IS NULL THEN 1 ELSE 0 END, customOrder, sortOrder, name")
    fun observeManageCategories(profileId: String): Flow<List<LiveCategoryEntity>>

    @Query("SELECT * FROM live_channels WHERE profileId = :profileId AND categoryId = :categoryId AND isHidden = 0 ORDER BY CASE WHEN customOrder IS NULL THEN 1 ELSE 0 END, customOrder, name")
    fun observeChannels(profileId: String, categoryId: String): Flow<List<LiveChannelEntity>>

    @Query("SELECT * FROM live_channels WHERE profileId = :profileId AND categoryId = :categoryId ORDER BY CASE WHEN customOrder IS NULL THEN 1 ELSE 0 END, customOrder, name")
    fun observeManageChannels(profileId: String, categoryId: String): Flow<List<LiveChannelEntity>>

    @Query("SELECT * FROM live_channels WHERE profileId = :profileId AND isHidden = 0 AND categoryId NOT IN (SELECT id FROM live_categories WHERE profileId = :profileId AND (isHidden = 1 OR isLocked = 1)) ORDER BY CASE WHEN customOrder IS NULL THEN 1 ELSE 0 END, customOrder, name")
    fun observeAllChannels(profileId: String): Flow<List<LiveChannelEntity>>

    @Query("SELECT * FROM live_channels WHERE profileId = :profileId AND streamId = :streamId LIMIT 1")
    fun observeChannel(profileId: String, streamId: Int): Flow<LiveChannelEntity?>

    @Query("SELECT * FROM live_channels WHERE profileId = :profileId AND isFavorite = 1 AND isHidden = 0 AND categoryId NOT IN (SELECT id FROM live_categories WHERE profileId = :profileId AND (isHidden = 1 OR isLocked = 1)) ORDER BY CASE WHEN customOrder IS NULL THEN 1 ELSE 0 END, customOrder, name")
    fun observeFavorites(profileId: String): Flow<List<LiveChannelEntity>>

    @Query("SELECT * FROM live_channels WHERE profileId = :profileId AND lastWatchedAt IS NOT NULL AND isHidden = 0 AND categoryId NOT IN (SELECT id FROM live_categories WHERE profileId = :profileId AND (isHidden = 1 OR isLocked = 1)) ORDER BY lastWatchedAt DESC LIMIT :limit")
    fun observeRecentChannels(profileId: String, limit: Int): Flow<List<LiveChannelEntity>>

    @Query("SELECT * FROM live_channels WHERE profileId = :profileId AND isHidden = 0 AND categoryId NOT IN (SELECT id FROM live_categories WHERE profileId = :profileId AND (isHidden = 1 OR isLocked = 1)) AND name LIKE '%' || :query || '%' ORDER BY name LIMIT :limit")
    fun searchLive(profileId: String, query: String, limit: Int = 100): Flow<List<LiveChannelEntity>>

    @Query("SELECT * FROM epg_programs WHERE profileId = :profileId AND streamId = :streamId ORDER BY startTimestamp")
    fun observeEpg(profileId: String, streamId: Int): Flow<List<EpgProgramEntity>>

    @Query("SELECT * FROM epg_programs WHERE profileId = :profileId AND streamId IN (:streamIds) ORDER BY streamId, startTimestamp")
    fun observeEpgForStreams(profileId: String, streamIds: List<Int>): Flow<List<EpgProgramEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertEpg(items: List<EpgProgramEntity>)

    @Query("DELETE FROM epg_programs WHERE profileId = :profileId AND streamId = :streamId")
    suspend fun clearEpg(profileId: String, streamId: Int)

    @Query("DELETE FROM epg_programs WHERE profileId = :profileId AND stopTimestamp < :cutoff")
    suspend fun deleteExpiredEpg(profileId: String, cutoff: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCategories(items: List<LiveCategoryEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertChannels(items: List<LiveChannelEntity>)

    @Query("UPDATE live_channels SET isFavorite = CASE WHEN isFavorite = 1 THEN 0 ELSE 1 END WHERE profileId = :profileId AND streamId = :streamId")
    suspend fun toggleFavorite(profileId: String, streamId: Int)

    @Query("UPDATE live_channels SET lastWatchedAt = :watchedAt WHERE profileId = :profileId AND streamId = :streamId")
    suspend fun markWatched(profileId: String, streamId: Int, watchedAt: Long)

    @Query("UPDATE live_channels SET isHidden = :hidden WHERE profileId = :profileId AND streamId = :streamId")
    suspend fun setChannelHidden(profileId: String, streamId: Int, hidden: Boolean)

    @Query("UPDATE live_channels SET customOrder = :customOrder WHERE profileId = :profileId AND streamId = :streamId")
    suspend fun setChannelOrder(profileId: String, streamId: Int, customOrder: Int)

    @Query("UPDATE live_categories SET isHidden = :hidden WHERE profileId = :profileId AND id = :categoryId")
    suspend fun setCategoryHidden(profileId: String, categoryId: String, hidden: Boolean)

    @Query("UPDATE live_categories SET isLocked = :locked WHERE profileId = :profileId AND id = :categoryId")
    suspend fun setCategoryLocked(profileId: String, categoryId: String, locked: Boolean)

    @Query("UPDATE live_categories SET customOrder = :customOrder WHERE profileId = :profileId AND id = :categoryId")
    suspend fun setCategoryOrder(profileId: String, categoryId: String, customOrder: Int)

    @Query("DELETE FROM live_categories WHERE profileId = :profileId")
    suspend fun clearCategories(profileId: String)

    @Query("DELETE FROM live_channels WHERE profileId = :profileId")
    suspend fun clearChannels(profileId: String)

    @Query("SELECT streamId FROM live_channels WHERE profileId = :profileId AND isFavorite = 1")
    suspend fun getFavoriteIds(profileId: String): List<Int>

    @Query("SELECT * FROM live_channels WHERE profileId = :profileId AND lastWatchedAt IS NOT NULL")
    suspend fun getWatched(profileId: String): List<LiveChannelEntity>

    @Query("SELECT streamId, isHidden, customOrder FROM live_channels WHERE profileId = :profileId")
    suspend fun getChannelPreferences(profileId: String): List<ChannelPreferenceRow>

    @Query("SELECT id, isHidden, isLocked, customOrder FROM live_categories WHERE profileId = :profileId")
    suspend fun getCategoryPreferences(profileId: String): List<CategoryPreferenceRow>

    @Transaction
    suspend fun replaceCatalog(profileId: String, categories: List<LiveCategoryEntity>, channels: List<LiveChannelEntity>) {
        val favorites = getFavoriteIds(profileId).toSet()
        val watched = getWatched(profileId).associate { it.streamId to it.lastWatchedAt }
        val channelPrefs = getChannelPreferences(profileId).associateBy { it.streamId }
        val categoryPrefs = getCategoryPreferences(profileId).associateBy { it.id }
        clearChannels(profileId)
        clearCategories(profileId)
        upsertCategories(categories.map { category ->
            val pref = categoryPrefs[category.id]
            category.copy(
                isHidden = pref?.isHidden ?: category.isHidden,
                isLocked = pref?.isLocked ?: category.isLocked,
                customOrder = pref?.customOrder ?: category.customOrder
            )
        })
        upsertChannels(channels.map { channel ->
            val pref = channelPrefs[channel.streamId]
            channel.copy(
                isFavorite = channel.streamId in favorites,
                lastWatchedAt = watched[channel.streamId],
                isHidden = pref?.isHidden ?: channel.isHidden,
                customOrder = pref?.customOrder ?: channel.customOrder
            )
        })
    }

    @Query("SELECT * FROM media_categories WHERE profileId = :profileId AND type = :type ORDER BY sortOrder, name")
    fun observeMediaCategories(profileId: String, type: String): Flow<List<MediaCategoryEntity>>

    @Query("SELECT * FROM vod_items WHERE profileId = :profileId AND categoryId = :categoryId ORDER BY name")
    fun observeVod(profileId: String, categoryId: String): Flow<List<VodItemEntity>>

    @Query("SELECT * FROM series_items WHERE profileId = :profileId AND categoryId = :categoryId ORDER BY name")
    fun observeSeries(profileId: String, categoryId: String): Flow<List<SeriesItemEntity>>

    @Query("SELECT * FROM vod_items WHERE profileId = :profileId AND name LIKE '%' || :query || '%' ORDER BY name LIMIT :limit")
    fun searchVod(profileId: String, query: String, limit: Int = 100): Flow<List<VodItemEntity>>

    @Query("SELECT * FROM series_items WHERE profileId = :profileId AND name LIKE '%' || :query || '%' ORDER BY name LIMIT :limit")
    fun searchSeries(profileId: String, query: String, limit: Int = 100): Flow<List<SeriesItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMediaCategories(items: List<MediaCategoryEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertVod(items: List<VodItemEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSeries(items: List<SeriesItemEntity>)

    @Query("DELETE FROM media_categories WHERE profileId = :profileId AND type = :type")
    suspend fun clearMediaCategories(profileId: String, type: String)

    @Query("DELETE FROM vod_items WHERE profileId = :profileId")
    suspend fun clearVod(profileId: String)

    @Query("DELETE FROM series_items WHERE profileId = :profileId")
    suspend fun clearSeries(profileId: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePlaybackPosition(item: PlaybackPositionEntity)

    @Query("SELECT * FROM playback_positions WHERE profileId = :profileId AND mediaKey = :mediaKey LIMIT 1")
    suspend fun getPlaybackPosition(profileId: String, mediaKey: String): PlaybackPositionEntity?

    @Query("SELECT * FROM playback_positions WHERE profileId = :profileId ORDER BY updatedAt DESC LIMIT :limit")
    fun observePlaybackPositions(profileId: String, limit: Int = 20): Flow<List<PlaybackPositionEntity>>

    @Query("DELETE FROM playback_positions WHERE profileId = :profileId AND mediaKey = :mediaKey")
    suspend fun clearPlaybackPosition(profileId: String, mediaKey: String)

    @Query("DELETE FROM epg_programs WHERE profileId = :profileId")
    suspend fun clearAllEpg(profileId: String)

    @Query("DELETE FROM playback_positions WHERE profileId = :profileId")
    suspend fun clearPlaybackPositions(profileId: String)

    @Query("DELETE FROM media_categories WHERE profileId = :profileId")
    suspend fun clearAllMediaCategories(profileId: String)

    @Transaction
    suspend fun deleteProfileData(profileId: String) {
        clearAllEpg(profileId)
        clearChannels(profileId)
        clearCategories(profileId)
        clearVod(profileId)
        clearSeries(profileId)
        clearAllMediaCategories(profileId)
        clearPlaybackPositions(profileId)
    }
}

data class ChannelPreferenceRow(val streamId: Int, val isHidden: Boolean, val customOrder: Int?)
data class CategoryPreferenceRow(val id: String, val isHidden: Boolean, val isLocked: Boolean, val customOrder: Int?)

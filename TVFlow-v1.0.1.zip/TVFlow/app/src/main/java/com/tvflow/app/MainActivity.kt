package com.tvflow.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.tvflow.app.ui.navigation.TVFlowNavHost
import com.tvflow.app.ui.theme.TVFlowTheme
import com.tvflow.app.ui.theme.ThemeViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    private val themeViewModel: ThemeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val accent by themeViewModel.accent.collectAsState()
            TVFlowTheme(accent = accent) {
                TVFlowNavHost()
            }
        }
    }
}

package com.tvflow.app.domain

data class XtreamCredentials(
    val serverUrl: String,
    val username: String,
    val password: String
)

data class ServerProfile(
    val id: String,
    val name: String,
    val credentials: XtreamCredentials
)

data class LiveCategory(
    val id: String,
    val name: String,
    val order: Int = 0,
    val isHidden: Boolean = false,
    val isLocked: Boolean = false
)

data class LiveChannel(
    val streamId: Int,
    val name: String,
    val categoryId: String,
    val logoUrl: String?,
    val epgChannelId: String?,
    val streamType: String = "live",
    val isFavorite: Boolean = false,
    val lastWatchedAt: Long? = null,
    val isHidden: Boolean = false,
    val customOrder: Int? = null
)

data class EpgProgram(
    val streamId: Int,
    val startTimestamp: Long,
    val stopTimestamp: Long,
    val title: String,
    val description: String?,
    val hasArchive: Boolean = false
) {
    fun isLiveAt(nowSeconds: Long): Boolean = nowSeconds in startTimestamp until stopTimestamp
}

# TVFlow

TVFlow est une application IPTV Android TV / Google TV orientée fluidité et télécommande.

## v0.4.0

- Connexion Xtream Codes et reprise automatique de session.
- TV en direct avec catégories, favoris, récents, EPG court et mini-guide.
- Zapping haut/bas dans le même lecteur Media3.
- Catalogue Films (VOD) et Séries indexé localement avec Room.
- Chargement des saisons/épisodes à la demande via `get_series_info`.
- Lecteur VOD/Séries avec reprise de lecture persistante.
- Recherche globale chaînes + films + séries.
- Dashboard TV pour accéder rapidement aux quatre zones principales.
- Synchronisation média parallèle pour réduire le temps de chargement initial.

## Stack

Kotlin, Jetpack Compose, Compose for TV, MVVM, Hilt, Room, Retrofit/OkHttp, Coroutines/Flow, DataStore et Media3.

## Build

```bash
./gradlew assembleDebug
```

APK attendu : `app/build/outputs/apk/debug/app-debug.apk`.

## GitLab CI

Le fichier `.gitlab-ci.yml` compile automatiquement l'APK debug et l'expose comme artifact.


## v0.5.0
- Guide TV dédié avec catégories, chaînes et programmes.
- Préchargement EPG limité/concurrent pour préserver les petites box Android TV.
- Rayon “Continuer à regarder” avec progression persistante.
- Modèle de reprise enrichi (titre, type, identifiant, extension).
- Base Room v5.

## v0.6.0

- Guide TV transformé en grille temporelle de 2 heures, navigation par pas de 30 minutes à la télécommande.
- Préchargement EPG limité aux 24 premières chaînes de la catégorie avec concurrence bornée.
- Préchauffage réseau des deux chaînes adjacentes au changement de chaîne (lecture limitée à 16 Ko et timeout court), sans second lecteur vidéo permanent.
- Accueil enrichi avec chaînes récentes, favoris et reprise de lecture.
- Optimisations volontairement bornées pour rester adaptées aux box Android TV à mémoire limitée.

## v0.7.0

- Refonte complète du guide TV en écran principal premium inspiré du principe des meilleurs lecteurs TV, sans reprendre leur code ni leurs ressources.
- Rail vertical de navigation TV avec accès Recherche, Accueil, Films et Séries.
- Colonne de groupes avec vues fonctionnelles `Favoris` et `Toutes les chaînes`.
- Panneau programme en haut synchronisé avec la chaîne ou le programme actuellement ciblé.
- Logos de chaînes intégrés avec fallback léger.
- Grille EPG compacte avec focus télécommande visible, programme en cours renforcé et ligne de temps actuelle.
- Navigation temporelle par pas de 30 minutes et retour immédiat à l'heure courante.
- Numérotation d'affichage indépendante des identifiants Xtream.
- Conservation du chargement EPG borné à 24 chaînes pour protéger la mémoire sur les petites box Android TV.

## v0.7.1

- Découplage du focus du guide et de la chaîne réellement affichée en aperçu.
- Parcourir les chaînes/programmes ne change plus automatiquement l’aperçu.
- Premier appui OK sur une autre chaîne : bascule de l’aperçu.
- Deuxième appui OK sur la chaîne déjà en aperçu : lecture plein écran.
- Réduit les changements de flux inutiles pendant la navigation EPG.

## v0.7.2

- Aperçu vidéo live réel dans l’en-tête du guide via Media3/ExoPlayer.
- Le lecteur d’aperçu est unique et réutilisé lors du changement de chaîne validé par OK.
- Le simple déplacement du focus dans le guide ne change jamais le flux d’aperçu.
- L’aperçu reste actif même si l’utilisateur change de catégorie dans le guide.
- Premier OK : syntonise l’aperçu sur la chaîne sélectionnée. Deuxième OK : ouvre le plein écran.
- Buffer court dédié à l’aperçu pour réduire le temps de démarrage sans conserver plusieurs lecteurs vidéo en parallèle.
- Fallback logo + état de chargement/erreur lorsque le flux d’aperçu n’est pas disponible.

## v0.8.0

Lecteur plein écran repensé pour un usage TV quotidien :

- overlay enrichi avec numéro, logo, programme en cours/suivant et progression ;
- zapping haut/bas sans recréer l'écran ;
- panneau rapide des chaînes à gauche ;
- panneau réglages à droite ;
- choix de piste audio ;
- choix/désactivation des sous-titres ;
- modes image Ajuster / Remplir / Zoom ;
- retour à la chaîne réellement regardée précédemment ;
- favoris accessibles directement depuis le lecteur ;
- appui long sur OK pour ouvrir les réglages ;
- 2 tentatives automatiques de reprise après erreur de lecture ;
- préchauffage des flux voisins conservé.

Raccourcis lecteur : `↑/↓` zapper, `←` chaînes, `→` réglages, `0` chaîne précédente, `OK` informations, appui long `OK` réglages.

## v0.9.0

- Profils multi-serveurs Xtream avec serveur actif et changement à chaud.
- Données Room isolées par profil pour éviter les collisions de `streamId` entre fournisseurs.
- Migration Room 5 -> 6 conservant les données historiques dans le profil `legacy`.
- Réglages persistants du lecteur : buffer FAST/BALANCED/SAFE, ratio FIT/FILL/ZOOM et sous-titres par défaut.
- Couleur d'accent personnalisable (bleu, turquoise, violet, ambre).
- Organisation des catégories et chaînes : masquer et réordonner.
- Contrôle parental par PIN SHA-256 et catégories verrouillables.
- Les catégories verrouillées demandent le PIN dans Direct et le Guide TV.
- Identifiants Xtream masqués dans les logs HTTP de debug.

## v1.0.0

Phase de stabilisation avant validation sur appareil :

- correction d'un import `OkHttpClient` invalide qui bloquait la compilation Kotlin ;
- migrations Room complètes `1 -> 2 -> 3 -> 4 -> 5 -> 6` et suppression de la migration destructive ;
- validation SQLite de la chaîne de migrations avec conservation des données historiques ;
- sauvegardes Android désactivées pour éviter d'exporter les identifiants Xtream stockés localement ;
- lecture Media3 synchronisée avec le lifecycle : pause en arrière-plan et reprise uniquement si la lecture était active ;
- sauvegarde périodique de la progression VOD/Séries toutes les 15 secondes ;
- CI GitLab renforcée avec tests unitaires, lint Android, build debug et rapports conservés en artifacts ;
- version application `1.0.0` (`versionCode 12`).

La validation finale exige encore un build Android réel et des tests sur box Android TV. L'environnement de développement courant ne peut pas joindre `services.gradle.org`, donc le compilateur Gradle ne peut pas être exécuté localement ici.

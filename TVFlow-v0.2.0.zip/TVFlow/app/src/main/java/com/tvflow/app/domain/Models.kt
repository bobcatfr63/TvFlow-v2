package com.tvflow.app.domain

data class XtreamCredentials(
    val serverUrl: String,
    val username: String,
    val password: String
)

data class LiveCategory(
    val id: String,
    val name: String,
    val order: Int = 0
)

data class LiveChannel(
    val streamId: Int,
    val name: String,
    val categoryId: String,
    val logoUrl: String?,
    val epgChannelId: String?,
    val streamType: String = "live",
    val isFavorite: Boolean = false,
    val lastWatchedAt: Long? = null
)

package com.tvflow.app.ui.navigation

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.tvflow.app.ui.home.HomeScreen
import com.tvflow.app.ui.login.LoginScreen
import com.tvflow.app.ui.player.PlayerScreen
import com.tvflow.app.ui.startup.StartupScreen

@Composable
fun TVFlowNavHost() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "startup") {
        composable("startup") {
            StartupScreen(
                onLoggedIn = {
                    navController.navigate("home") { popUpTo("startup") { inclusive = true } }
                },
                onLoggedOut = {
                    navController.navigate("login") { popUpTo("startup") { inclusive = true } }
                }
            )
        }
        composable("login") {
            LoginScreen(
                onLoggedIn = {
                    navController.navigate("home") {
                        popUpTo("login") { inclusive = true }
                    }
                }
            )
        }
        composable("home") {
            HomeScreen { channel ->
                navController.navigate(
                    "player/${channel.streamId}/${Uri.encode(channel.name)}/${Uri.encode(channel.categoryId)}"
                )
            }
        }
        composable(
            route = "player/{streamId}/{name}/{categoryId}",
            arguments = listOf(
                navArgument("streamId") { type = NavType.IntType },
                navArgument("name") { type = NavType.StringType },
                navArgument("categoryId") { type = NavType.StringType }
            )
        ) {
            PlayerScreen()
        }
    }
}

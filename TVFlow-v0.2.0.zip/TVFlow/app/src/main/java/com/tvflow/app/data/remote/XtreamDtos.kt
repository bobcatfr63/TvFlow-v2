package com.tvflow.app.data.remote

import com.google.gson.annotations.SerializedName

data class XtreamAuthResponse(
    @SerializedName("user_info") val userInfo: UserInfo?,
    @SerializedName("server_info") val serverInfo: ServerInfo?
) {
    data class UserInfo(
        val username: String? = null,
        val password: String? = null,
        val message: String? = null,
        val auth: Int? = null,
        val status: String? = null,
        @SerializedName("exp_date") val expiryDate: String? = null,
        @SerializedName("is_trial") val isTrial: String? = null,
        @SerializedName("active_cons") val activeConnections: String? = null,
        @SerializedName("max_connections") val maxConnections: String? = null
    )

    data class ServerInfo(
        val url: String? = null,
        val port: String? = null,
        val protocol: String? = null,
        val timezone: String? = null,
        @SerializedName("timestamp_now") val timestampNow: Long? = null
    )
}

data class LiveCategoryDto(
    @SerializedName("category_id") val categoryId: String,
    @SerializedName("category_name") val categoryName: String,
    @SerializedName("parent_id") val parentId: Int? = null
)

data class LiveStreamDto(
    @SerializedName("num") val number: Int? = null,
    val name: String,
    @SerializedName("stream_type") val streamType: String? = null,
    @SerializedName("stream_id") val streamId: Int,
    @SerializedName("stream_icon") val streamIcon: String? = null,
    @SerializedName("epg_channel_id") val epgChannelId: String? = null,
    @SerializedName("category_id") val categoryId: String? = null,
    @SerializedName("tv_archive") val tvArchive: Int? = null,
    @SerializedName("tv_archive_duration") val tvArchiveDuration: Int? = null
)

package com.tvflow.app.data.repository

import com.tvflow.app.data.local.CredentialsStore
import com.tvflow.app.data.local.LiveCategoryEntity
import com.tvflow.app.data.local.LiveChannelEntity
import com.tvflow.app.data.local.TVFlowDao
import com.tvflow.app.data.remote.XtreamApi
import com.tvflow.app.domain.LiveCategory
import com.tvflow.app.domain.LiveChannel
import com.tvflow.app.domain.XtreamCredentials
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class XtreamRepository @Inject constructor(
    private val api: XtreamApi,
    private val dao: TVFlowDao,
    private val credentialsStore: CredentialsStore
) {
    val savedCredentials = credentialsStore.credentials

    suspend fun login(credentials: XtreamCredentials) {
        val normalized = credentials.copy(serverUrl = normalizeServer(credentials.serverUrl))
        val response = api.authenticate(
            playerApiUrl = playerApi(normalized.serverUrl),
            username = normalized.username,
            password = normalized.password
        )
        val authenticated = response.userInfo?.auth == 1 || response.userInfo?.status.equals("Active", true)
        if (!authenticated) error(response.userInfo?.message ?: "Identifiants Xtream refusés")
        credentialsStore.save(normalized)
        refreshCatalog(normalized)
    }

    suspend fun refreshCatalog() {
        val credentials = savedCredentials.first() ?: error("Aucun serveur IPTV configuré")
        refreshCatalog(credentials)
    }

    private suspend fun refreshCatalog(credentials: XtreamCredentials) {
        val apiUrl = playerApi(credentials.serverUrl)
        val categories = api.getLiveCategories(apiUrl, credentials.username, credentials.password)
        val channels = api.getLiveStreams(apiUrl, credentials.username, credentials.password)

        dao.replaceCatalog(
            categories = categories.mapIndexed { index, dto ->
                LiveCategoryEntity(dto.categoryId, dto.categoryName, index)
            },
            channels = channels.map { dto ->
                LiveChannelEntity(
                    streamId = dto.streamId,
                    name = dto.name,
                    categoryId = dto.categoryId.orEmpty(),
                    logoUrl = dto.streamIcon?.takeIf { it.isNotBlank() },
                    epgChannelId = dto.epgChannelId?.takeIf { it.isNotBlank() },
                    streamType = dto.streamType ?: "live"
                )
            }
        )
    }

    fun observeCategories(): Flow<List<LiveCategory>> = dao.observeCategories().map { list ->
        list.map { LiveCategory(it.id, it.name, it.sortOrder) }
    }

    fun observeChannels(categoryId: String): Flow<List<LiveChannel>> = dao.observeChannels(categoryId).map(::mapChannels)

    fun observeChannel(streamId: Int): Flow<LiveChannel?> = dao.observeChannel(streamId).map { it?.toDomain() }

    fun observeFavorites(): Flow<List<LiveChannel>> = dao.observeFavorites().map(::mapChannels)

    fun observeRecentChannels(limit: Int = 20): Flow<List<LiveChannel>> = dao.observeRecentChannels(limit).map(::mapChannels)

    suspend fun toggleFavorite(streamId: Int) = dao.toggleFavorite(streamId)

    suspend fun markWatched(streamId: Int) = dao.markWatched(streamId, System.currentTimeMillis())

    fun streamUrl(credentials: XtreamCredentials, channel: LiveChannel): String {
        val base = normalizeServer(credentials.serverUrl)
        return "$base/live/${credentials.username}/${credentials.password}/${channel.streamId}.ts"
    }

    suspend fun logout() {
        credentialsStore.clear()
    }

    private fun mapChannels(list: List<LiveChannelEntity>) = list.map { it.toDomain() }

    private fun LiveChannelEntity.toDomain() = LiveChannel(
        streamId = streamId,
        name = name,
        categoryId = categoryId,
        logoUrl = logoUrl,
        epgChannelId = epgChannelId,
        streamType = streamType,
        isFavorite = isFavorite,
        lastWatchedAt = lastWatchedAt
    )

    private fun playerApi(server: String): String = "${normalizeServer(server)}/player_api.php"

    private fun normalizeServer(raw: String): String {
        var value = raw.trim().trimEnd('/')
        if (!value.startsWith("http://") && !value.startsWith("https://")) value = "http://$value"
        return value
    }
}

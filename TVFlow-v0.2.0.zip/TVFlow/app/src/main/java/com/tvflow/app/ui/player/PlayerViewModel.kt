package com.tvflow.app.ui.player

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tvflow.app.data.repository.XtreamRepository
import com.tvflow.app.domain.LiveChannel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class PlayerUiState(
    val channel: LiveChannel? = null,
    val streamUrl: String? = null,
    val channelIndex: Int = -1,
    val channelCount: Int = 0
)

@HiltViewModel
class PlayerViewModel @Inject constructor(
    private val repository: XtreamRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {
    private val initialStreamId: Int = checkNotNull(savedStateHandle["streamId"])
    private val categoryId: String = savedStateHandle["categoryId"] ?: ""
    private val selectedStreamId = MutableStateFlow(initialStreamId)

    private val channelList: StateFlow<List<LiveChannel>> = repository.observeChannels(categoryId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val uiState: StateFlow<PlayerUiState> = combine(
        repository.savedCredentials,
        channelList,
        selectedStreamId
    ) { credentials, list, streamId ->
        val index = list.indexOfFirst { it.streamId == streamId }
        val channel = list.getOrNull(index)
        PlayerUiState(
            channel = channel,
            streamUrl = if (credentials != null && channel != null) repository.streamUrl(credentials, channel) else null,
            channelIndex = index,
            channelCount = list.size
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), PlayerUiState())

    init {
        markWatched(initialStreamId)
    }

    fun nextChannel() = move(+1)

    fun previousChannel() = move(-1)

    fun toggleFavorite() {
        val streamId = uiState.value.channel?.streamId ?: return
        viewModelScope.launch { repository.toggleFavorite(streamId) }
    }

    private fun move(delta: Int) {
        val state = uiState.value
        if (state.channelCount <= 1 || state.channelIndex < 0) return
        val nextIndex = (state.channelIndex + delta + state.channelCount) % state.channelCount
        val next = channelList.value.getOrNull(nextIndex) ?: return
        selectedStreamId.value = next.streamId
        markWatched(next.streamId)
    }

    private fun markWatched(streamId: Int) {
        viewModelScope.launch { repository.markWatched(streamId) }
    }
}

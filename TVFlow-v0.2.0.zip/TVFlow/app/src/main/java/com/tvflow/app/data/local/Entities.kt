package com.tvflow.app.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "live_categories")
data class LiveCategoryEntity(
    @PrimaryKey val id: String,
    val name: String,
    val sortOrder: Int
)

@Entity(
    tableName = "live_channels",
    indices = [Index("categoryId"), Index("name"), Index("isFavorite"), Index("lastWatchedAt")]
)
data class LiveChannelEntity(
    @PrimaryKey val streamId: Int,
    val name: String,
    val categoryId: String,
    val logoUrl: String?,
    val epgChannelId: String?,
    val streamType: String,
    val isFavorite: Boolean = false,
    val lastWatchedAt: Long? = null
)

package com.tvflow.app.data.local

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.tvflow.app.domain.XtreamCredentials
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "tvflow_settings")

@Singleton
class CredentialsStore @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val server = stringPreferencesKey("server")
        val username = stringPreferencesKey("username")
        val password = stringPreferencesKey("password")
    }

    val credentials: Flow<XtreamCredentials?> = context.dataStore.data.map { prefs ->
        val server = prefs[Keys.server]
        val username = prefs[Keys.username]
        val password = prefs[Keys.password]
        if (server.isNullOrBlank() || username.isNullOrBlank() || password.isNullOrBlank()) null
        else XtreamCredentials(server, username, password)
    }

    suspend fun save(value: XtreamCredentials) {
        context.dataStore.edit { prefs ->
            prefs[Keys.server] = value.serverUrl
            prefs[Keys.username] = value.username
            prefs[Keys.password] = value.password
        }
    }

    suspend fun clear() {
        context.dataStore.edit { it.clear() }
    }
}

package com.tvflow.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [LiveCategoryEntity::class, LiveChannelEntity::class],
    version = 2,
    exportSchema = true
)
abstract class TVFlowDatabase : RoomDatabase() {
    abstract fun dao(): TVFlowDao
}

package com.tvflow.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface TVFlowDao {
    @Query("SELECT * FROM live_categories ORDER BY sortOrder, name")
    fun observeCategories(): Flow<List<LiveCategoryEntity>>

    @Query("SELECT * FROM live_channels WHERE categoryId = :categoryId ORDER BY name")
    fun observeChannels(categoryId: String): Flow<List<LiveChannelEntity>>

    @Query("SELECT * FROM live_channels WHERE streamId = :streamId LIMIT 1")
    fun observeChannel(streamId: Int): Flow<LiveChannelEntity?>

    @Query("SELECT * FROM live_channels WHERE isFavorite = 1 ORDER BY name")
    fun observeFavorites(): Flow<List<LiveChannelEntity>>

    @Query("SELECT * FROM live_channels WHERE lastWatchedAt IS NOT NULL ORDER BY lastWatchedAt DESC LIMIT :limit")
    fun observeRecentChannels(limit: Int): Flow<List<LiveChannelEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCategories(items: List<LiveCategoryEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertChannels(items: List<LiveChannelEntity>)

    @Query("UPDATE live_channels SET isFavorite = CASE WHEN isFavorite = 1 THEN 0 ELSE 1 END WHERE streamId = :streamId")
    suspend fun toggleFavorite(streamId: Int)

    @Query("UPDATE live_channels SET lastWatchedAt = :watchedAt WHERE streamId = :streamId")
    suspend fun markWatched(streamId: Int, watchedAt: Long)

    @Query("DELETE FROM live_categories")
    suspend fun clearCategories()

    @Query("DELETE FROM live_channels")
    suspend fun clearChannels()

    @Transaction
    suspend fun replaceCatalog(
        categories: List<LiveCategoryEntity>,
        channels: List<LiveChannelEntity>
    ) {
        val favorites = getFavoriteIds().toSet()
        val watched = getWatched().associate { it.streamId to it.lastWatchedAt }
        clearChannels()
        clearCategories()
        upsertCategories(categories)
        upsertChannels(channels.map { channel ->
            channel.copy(
                isFavorite = channel.streamId in favorites,
                lastWatchedAt = watched[channel.streamId]
            )
        })
    }

    @Query("SELECT streamId FROM live_channels WHERE isFavorite = 1")
    suspend fun getFavoriteIds(): List<Int>

    @Query("SELECT * FROM live_channels WHERE lastWatchedAt IS NOT NULL")
    suspend fun getWatched(): List<LiveChannelEntity>
}

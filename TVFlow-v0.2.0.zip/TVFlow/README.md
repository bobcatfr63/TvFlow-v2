# TVFlow

Application IPTV Android TV / Google TV centrée sur la fluidité et la navigation télécommande.

## État v0.1

- Connexion Xtream Codes
- Authentification via `player_api.php`
- Synchronisation des catégories Live
- Synchronisation des chaînes Live
- Cache Room local
- Navigation catégories → chaînes
- Lecture des flux Live via Media3 / ExoPlayer
- Pipeline GitLab CI produisant un APK debug

## Architecture

- Kotlin 2.4.20
- Jetpack Compose
- MVVM
- Hilt
- Room
- DataStore
- Retrofit / OkHttp
- Media3

## Import Android Studio

Ouvrir le dossier `TVFlow` puis laisser Gradle synchroniser le projet.

## Build local

```bash
./gradlew assembleDebug
```

APK attendu :

`app/build/outputs/apk/debug/app-debug.apk`

## GitLab

Créer un dépôt privé puis pousser le dossier. `.gitlab-ci.yml` compile automatiquement l'APK debug.

## Sécurité

La v0.1 accepte temporairement les serveurs HTTP (`usesCleartextTraffic=true`) car de nombreux services Xtream utilisent encore HTTP. Les identifiants sont stockés dans DataStore. Une version suivante remplacera cela par un stockage chiffré et une Network Security Config restrictive.

## Prochaine tranche

1. Écran de démarrage qui détecte automatiquement une session existante.
2. EPG XMLTV / short EPG.
3. Favoris, historique et reprise de lecture.
4. VOD, séries, saisons et épisodes.
5. Recherche instantanée indexée localement.
6. Pagination et stratégie de synchronisation incrémentale.
7. Player TV avec zapping haut/bas et overlay programme en cours.
8. Baseline Profile + Macrobenchmark.
9. Fallback libVLC optionnel pour les flux incompatibles Media3.

## v0.2.0

- reprise automatique de session Xtream au démarrage ;
- favoris persistants ;
- historique des chaînes récemment regardées ;
- conservation des favoris et de l'historique lors d'une resynchronisation du catalogue ;
- zapping haut/bas directement dans le lecteur ;
- overlay TV avec nom de chaîne, position dans la catégorie et état favori ;
- lecteur Media3 conservé pendant le changement de chaîne ;
- migration de la base Room vers la version 2.

### Commandes télécommande dans le lecteur

- Haut / Channel+ : chaîne précédente ;
- Bas / Channel- : chaîne suivante ;
- OK / Entrée : afficher ou masquer l'overlay ;
- touche F ou Record : ajouter/retirer le favori (selon télécommande/clavier).
